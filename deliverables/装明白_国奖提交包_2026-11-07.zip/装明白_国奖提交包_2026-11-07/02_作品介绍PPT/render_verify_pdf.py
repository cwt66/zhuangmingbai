# -*- coding: utf-8 -*-
"""把《装明白_评委复验页.html》渲染成 10 页 PDF。

为什么要有这个脚本
------------------
之前这份 PDF 是临时用无头浏览器截的，没留脚本。重渲时踩到一个坑：
10 张截图**全部一样**——因为 `.slide` 是 `position:absolute; inset:0` 叠在一起的，
一次性给所有页加 `.visible`，截到的永远是最后一张（它盖在最上层）。
这个脚本改成**逐页单独显示再截**，并强制校验 10 张图互不相同，否则直接报错。

依赖：playwright（本机已有 chromium）、Pillow。
用法：
    python3 render_verify_pdf.py            # → 装明白_评委复验页_10页.pdf
"""
import hashlib
import os
import sys

from PIL import Image
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
HTML = os.path.join(HERE, "装明白_评委复验页.html")
OUT = os.path.join(HERE, "装明白_评委复验页_10页.pdf")
TMP = os.path.join(HERE, ".render_tmp")


def main():
    if not os.path.exists(HTML):
        raise SystemExit("找不到 HTML：" + HTML)
    os.makedirs(TMP, exist_ok=True)

    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page(viewport={"width": 1920, "height": 1080},
                                device_scale_factor=1)
        page.goto("file://" + HTML)
        page.wait_for_timeout(600)
        n = page.evaluate("document.querySelectorAll('.slide').length")
        print("页数：%d" % n)

        # 关掉动效、隐藏控制条：复验文档要的是「一眼能读完」，不是表演
        page.evaluate("""() => {
          document.querySelectorAll('.deck-controls').forEach(e => e.remove());
          document.querySelectorAll('.reveal').forEach(e => {
            e.style.transition = 'none'; e.style.opacity = 1; e.style.transform = 'none';
          });
          document.body.style.overflow = 'hidden';
        }""")

        shots = []
        for i in range(n):
            page.evaluate("""(i) => {
              document.querySelectorAll('.slide').forEach((s, k) => {
                s.classList.toggle('visible', k === i);
                s.classList.toggle('active', k === i);
              });
            }""", i)
            page.wait_for_timeout(120)
            path = os.path.join(TMP, "s%02d.png" % (i + 1))
            page.locator(".slide").nth(i).screenshot(path=path)
            shots.append(path)
        browser.close()

    # 防回归：每页必须不同（曾经 10 页全一样）
    hashes = [hashlib.md5(open(p, "rb").read()).hexdigest() for p in shots]
    if len(set(hashes)) != n:
        raise SystemExit("截图重复：%d 张里只有 %d 种，检查 .slide 叠加逻辑"
                         % (n, len(set(hashes))))

    ims = [Image.open(p).convert("RGB") for p in shots]
    ims[0].save(OUT, "PDF", resolution=144.0, save_all=True, append_images=ims[1:])
    print("生成 %s（%d 页，%.1f MB）"
          % (os.path.basename(OUT), n, os.path.getsize(OUT) / 1024 / 1024))


if __name__ == "__main__":
    main()
