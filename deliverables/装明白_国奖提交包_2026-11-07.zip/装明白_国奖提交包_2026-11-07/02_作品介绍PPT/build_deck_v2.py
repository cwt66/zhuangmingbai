# -*- coding: utf-8 -*-
"""生成国奖版 16 页作品介绍（3840×2160，沿用原设计语言）。

为什么用 PIL 画：仓库里没有可用的 HTML→PNG 渲染器（无 Chrome/qlmanage 受限），
而原 13 页是画布导出的位图。这里用同一套设计令牌（纸白/墨黑/琥珀/国际蓝、
大字号细体、16 列网格的留白）重绘需要更新数字的页面，并补 3 页国奖叙事。

输出：
    slides_v2/s01.png ... s16.png
    装明白_国奖版_16页.pptx / .pdf
    装明白_一页版.pdf
"""
import glob
import os
import sys

from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation
from pptx.util import Emu

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "slides_v2")
W, H = 3840, 2160
M = 160

PAPER = (250, 250, 248)
INK = (10, 10, 10)
INK2 = (86, 96, 108)
MUTED = (138, 135, 127)
LINE = (228, 226, 220)
AMBER = (176, 122, 34)
BLUE = (0, 47, 167)
RED = (179, 58, 43)
WHITE = (255, 255, 255)
DARK = (12, 14, 18)

FONT_B = "/System/Library/Fonts/STHeiti Medium.ttc"
FONT_R = "/System/Library/Fonts/Hiragino Sans GB.ttc"


def fb(size):
    return ImageFont.truetype(FONT_B, size)


def fr(size):
    return ImageFont.truetype(FONT_R, size)


def wrap(draw, text, font, maxw):
    lines = []
    for para in (text or "").split("\n"):
        cur = ""
        for ch in para:
            if draw.textlength(cur + ch, font=font) <= maxw:
                cur += ch
            else:
                if cur:
                    lines.append(cur)
                cur = ch
        lines.append(cur)
    return lines


def text_block(draw, x, y, text, font, fill, maxw, line_h=None, max_lines=None):
    lines = wrap(draw, text, font, maxw)
    if max_lines:
        lines = lines[:max_lines]
    lh = line_h or int(font.size * 1.55)
    for i, line in enumerate(lines):
        draw.text((x, y + i * lh), line, font=font, fill=fill)
    return y + len(lines) * lh


def new_page(kicker, title, lead=None, dark=False):
    im = Image.new("RGB", (W, H), DARK if dark else PAPER)
    d = ImageDraw.Draw(im)
    fg = WHITE if dark else INK
    d.text((M, 110), kicker, font=fb(46), fill=AMBER)
    d.text((M, 196), title, font=fb(106), fill=fg)
    y = 350
    if lead:
        y = text_block(d, M, 350, lead, fr(50), (200, 200, 200) if dark else INK2, W - 2 * M, 76)
    d.line((M, y + 34, W - M, y + 34), fill=(70, 70, 70) if dark else INK, width=3)
    return im, d, y + 90


def footer(d, page, dark=False):
    d.text((M, H - 100), "装明白 · 可计算审计", font=fr(34), fill=(120, 120, 120) if dark else MUTED)
    d.text((W - M - 60, H - 100), "%02d" % page, font=fr(34), fill=(120, 120, 120) if dark else MUTED)


def card(d, x, y, w, h, num, title, body, accent=AMBER, dark=False):
    d.rectangle((x, y, x + w, y + h), fill=DARK if dark else WHITE, outline=(50, 50, 50) if dark else LINE, width=2)
    d.rectangle((x, y, x + w, y + 6), fill=accent)
    if num:
        d.text((x + 34, y + 30), num, font=fb(40), fill=accent)
    ty = y + 92 if num else y + 34
    d.text((x + 34, ty), title, font=fb(56), fill=WHITE if dark else INK)
    text_block(d, x + 34, ty + 78, body, fr(38), (200, 200, 200) if dark else INK2, w - 68, 58)


def stat(d, x, y, big, label, sub=None, color=INK, big_size=150):
    d.text((x, y), big, font=fb(big_size), fill=color)
    d.text((x, y + big_size + 12), label, font=fb(40), fill=INK)
    if sub:
        text_block(d, x, y + big_size + 70, sub, fr(34), MUTED, 900, 48)


# ---------------------------------------------------------------- pages
def p01_cover():
    im = Image.new("RGB", (W, H), DARK)
    d = ImageDraw.Draw(im)
    # 右侧几何：一根竖轴 + 刻度 + 点
    x0, y0 = 2860, 420
    d.line((x0, y0, x0, 1680), fill=(70, 74, 82), width=3)
    for i in range(7):
        yy = y0 + i * 200
        d.line((x0 - 520, yy, x0 + 20, yy), fill=(48, 52, 60), width=2)
        d.ellipse((x0 - 12, yy - 12, x0 + 12, yy + 12), fill=AMBER if i in (0, 2, 4, 6) else (110, 110, 110))
    d.text((M, 220), "第十一届华为 ICT 大赛 · 中国创新赛 · 赛题1", font=fb(52), fill=(190, 190, 190))
    d.text((M, 380), "装明白", font=fb(330), fill=WHITE)
    d.text((M, 800), "COMPUTABLE AUDIT FOR RENOVATION QUOTES", font=fr(46), fill=(150, 150, 150))
    d.text((M, 930), "把装修报价，变成一张可核对的表", font=fb(96), fill=AMBER)
    d.line((M, 1080, M + 260, 1080), fill=AMBER, width=6)
    text_block(d, M, 1170,
               "把现实里数百种模糊叫法映射到 119 个标准概念组成的坐标轴，\n"
               "判断交给可解释的规则，每条结论带一个证据强度分。\n"
               "我们不判断贵不贵，只判断漏没漏、重没重。",
               fr(52), (205, 205, 205), 1850, 82)
    d.text((M, 1850), "参赛队：【学校】·【队名】    队员：【姓名】【姓名】【姓名】    指导教师：【姓名】",
           font=fr(42), fill=(150, 150, 150))
    d.text((M, 1930), "2026.11 ｜ 开源：gitee.com/Cwt66/zhuangmingbai ｜ MIT", font=fr(38), fill=(110, 110, 110))
    return im


def p05_ontology():
    im, d, y = new_page("04  组件一 · 工序轴对齐 WUA", "把 119 个概念，映射到同一根轴上",
                        "同一道工序有五种叫法、三种计价单位——先归一，才谈得上比较。")
    rows = [
        ("同义", "墙固 ≡ 界面剂 ≡ 基层处理  →  判等合并"),
        ("上下位", "水电改造（包含）开槽 / 布线 / 打压  →  先归并到父节点再比"),
        ("单位换算", "按项 / 按㎡ / 按 m  →  用面积与周长反算，不可换算项单列风险"),
    ]
    yy = y + 20
    for name, body in rows:
        d.text((M, yy), name, font=fb(52), fill=INK)
        text_block(d, M, yy + 70, body, fr(40), INK2, 1750, 56)
        yy += 175
    # 右：60 个真实项目名
    bx, by, bw = 2100, y + 20, 1500
    d.text((bx, by), "60 个真实项目名的对齐结果", font=fb(42), fill=INK)
    bars = [("精确 / 别名命中", 0.833, AMBER), ("模糊命中（需人工确认）", 0.167, (188, 163, 112)), ("本体缺口", 0.0, MUTED)]
    yy = by + 100
    for label, v, col in bars:
        d.text((bx, yy), label, font=fr(36), fill=INK2)
        d.rectangle((bx, yy + 52, bx + bw, yy + 108), fill=(242, 241, 236))
        if v > 0:
            d.rectangle((bx, yy + 52, bx + int(bw * v), yy + 108), fill=col)
        d.text((bx + bw - 220, yy + 54), "%.1f%%" % (v * 100), font=fb(46), fill=INK)
        yy += 190
    # 四级对齐
    d.text((M, 1035), "四级对齐（置信度从高到低）", font=fb(40), fill=INK)
    levels = [("精确", "0.98", "正式名完全一致"), ("别名", "0.95", "真实叫法命中"),
              ("模糊", "0.62–0.90", "编辑距离；需人工确认"), ("包含", "0.85", "长名包含短名，≥2 字")]
    for i, (a, b, c) in enumerate(levels):
        x = M + i * 560
        d.text((x, 1105), a, font=fb(44), fill=INK)
        d.text((x, 1165), b, font=fb(40), fill=AMBER)
        text_block(d, x, 1221, c, fr(30), MUTED, 500, 40)
    text_block(d, M, 1310, "都打不中 → 本体缺口，列清单，不猜。我们就是靠 18 条缺口把覆盖从 53.3% 补到 83.3%。",
               fr(34), INK2, 2600, 46)
    # 底部三个数
    stat(d, M, 1450, "119", "工序概念", "8 大类 · 含同义词/上下位/单位换算", INK, 130)
    stat(d, M + 620, 1450, "388", "同义别名", "真实单据里出现过的叫法", INK, 130)
    stat(d, M + 1240, 1450, "67", "工序模板项", "老房 39 + 新房 28", INK, 130)
    d.line((M, 1840, W - M, 1840), fill=LINE, width=2)
    text_block(d, M, 1880, "18 条缺口全部补入（主材 12 / 五金 2 / 施工 3 / 费用 1），覆盖 53.3% → 83.3%，缺口清零。",
               fr(38), INK2, W - 2 * M, 56)
    footer(d, 5)
    return im


def p06_rules():
    im, d, y = new_page("05  组件二 · 审计规则 DSL", "判断不经过大模型：13 条规则，可逐条审阅",
                        "规则只依赖本体与模板，不依赖任何价格数据。")
    # 代码块
    d.rectangle((M, y + 10, 2050, y + 760), fill=(16, 18, 22))
    code = [
        "RULE missing_item",
        "WHEN template = 老房翻新",
        "  AND NOT exists(item, unit = 铲墙皮)",
        "THEN 结论 = 「缺项：铲墙皮」",
        "WITH evidence = { row: 0,",
        "       basis: 「老房标准工序 T.line_3」,",
        "       formula: 「模板 − 实列」 }",
        "AND severity = high",
    ]
    yy = y + 60
    for line in code:
        d.text((M + 50, yy), line, font=fr(38), fill=(230, 230, 230))
        yy += 74
    d.text((M, y + 790), "规则示例：漏项判定。三类审计都长这样，人可以读懂，也可以反驳。",
           font=fr(34), fill=MUTED)
    # 右侧三条
    rx = 2180
    items = [
        ("漏项", "集合差：标准工序模板里有、这份报价里没有"),
        ("重复计价", "同概念多行计费；不同部位/规格的变体直接排除"),
        ("口径混用", "单位不一致，或出现按实结算 / 暂定 / 据实"),
    ]
    yy = y + 20
    for name, body in items:
        d.text((rx, yy), name, font=fb(52), fill=INK)
        text_block(d, rx, yy + 70, body, fr(38), INK2, 1450, 56)
        yy += 190
    text_block(d, rx, yy + 10, "不依赖价格库，所以既避开数据质疑，也避开合规质疑——我们不对定价合理性作任何断言。",
               fr(36), AMBER, 1450, 56)
    # 规则清单
    d.text((M, 1240), "13 条规则（全部可逐条审阅）", font=fb(40), fill=INK)
    rules = ["R1 漏项差集", "R2 工艺包含", "R3 同概念多行", "R4 口径模糊", "R5 跨单单位",
             "R6 单位异常", "R7 拆分计价", "R8 算术", "R9 量纲", "R10 管理费率",
             "R11 规格缺失", "R12 防水高度", "R13 文档对账"]
    for i, r in enumerate(rules):
        x = M + (i % 7) * 500
        y = 1310 + (i // 7) * 76
        d.text((x, y), r, font=fr(32), fill=INK2)
    d.line((M, 1540, W - M, 1540), fill=LINE, width=2)
    for i, (t, b) in enumerate([("可扩展", "加规则不改代码，JSON 里写一条就生效"),
                                ("可解释", "人能读懂为什么判定，不是一句「AI 认为」"),
                                ("可审查", "规则库随项目开源，评委可以直接翻")]):
        x = M + i * 1180
        d.text((x, 1600), t, font=fb(44), fill=INK)
        d.text((x, 1660), b, font=fr(32), fill=INK2)
    footer(d, 6)
    return im


def p09_eval():
    im, d, y = new_page("08  评测", "评测：小样本，但每个数字都能查",
                        "5 份真实单据 / 603 行工序明细 · 2 份完整黄金标注 · n 小，所以两档并报。")
    # 四个大数
    stats = [("5", "份真实单据", "4 家装 + 1 工装"),
             ("603", "行工序明细", "+ 11 行汇总单列对账"),
             ("0.833", "auto 精确率", "召回率同为 0.833（n=2）"),
             ("243", "个单元测试", "一条命令全绿")]
    for i, (big, lab, sub) in enumerate(stats):
        stat(d, M + i * 900, y + 10, big, lab, sub, INK, 140)
    # 表格
    ty = y + 330
    rows = [
        ("黄金标注 auto 档", "TP 10 / FP 2 / FN 2", "精确率 0.833、召回率 0.833（Wilson 95%CI 0.552–0.953）"),
        ("黄金标注 all 档", "TP 12 / FP 4 / FN 0", "召回率 1.000；含待确认档，单列不混报"),
        ("重复计价", "误报 0 条", "21 组同概念多行经变体判别全部排除"),
        ("注入实验", "242 / 242", "下限校验，不是召回率；对外必须带这句"),
        ("单份审计", "约 89.2ms", "纯规则判定 0.33ms；本机实测，不作云端承诺"),
    ]
    d.text((M, ty), "指标", font=fb(38), fill=INK)
    d.text((M + 640, ty), "结果", font=fb(38), fill=INK)
    d.text((M + 1280, ty), "口径 / 说明", font=fb(38), fill=INK)
    d.line((M, ty + 56, W - M, ty + 56), fill=INK, width=3)
    yy = ty + 86
    for a, b, c in rows:
        d.text((M, yy), a, font=fb(40), fill=INK)
        d.text((M + 640, yy), b, font=fb(40), fill=AMBER)
        text_block(d, M + 1280, yy, c, fr(34), INK2, 2100, 48)
        d.line((M, yy + 92, W - M, yy + 92), fill=LINE, width=2)
        yy += 116
    # 底部消融结论
    d.rectangle((M, 1830, W - M, 1970), fill=(14, 16, 20))
    text_block(d, M + 40, 1850, "消融：L0 仅精确匹配 auto 精确率 0.267 → L1 0.421 → L2 0.800。"
                                "坐标系不是形容词，是能把误报压下去的组件。",
               fr(38), WHITE, W - 2 * M - 80, 54)
    footer(d, 9)
    return im


def p10_cloud():
    im, d, y = new_page("09  华为云落地", "不是堆服务：每个都在链路里有位置",
                        "CodeArts 走完五环节；RDS / Redis / MaaS 在代码里真的被调用，失败降级并如实显示。")
    # 左：五环节
    stages = [
        ("01", "需求理解", "把「三类审计」写成可验收条款"),
        ("02", "代码生成", "本体 101→119，覆盖 53.3%→83.3%"),
        ("03", "项目构建", "Dockerfile；人修掉 curl 健康检查"),
        ("04", "问题修复", "空 CSV 500→400；17 个真实数据缺陷"),
        ("05", "部署上线", "RDS/OBS 命令行；Redis 走控制台"),
    ]
    yy = y + 10
    for num, name, body in stages:
        d.text((M, yy), num, font=fb(34), fill=AMBER)
        d.text((M + 100, yy - 6), name, font=fb(46), fill=INK)
        d.text((M + 440, yy + 2), body, font=fr(34), fill=INK2)
        yy += 130
    d.text((M, 1150), "可复核的三个入口", font=fb(42), fill=INK)
    text_block(d, M, 1220,
               "/health 逐项返回 db / cache / llm 状态，失败写 degraded；\n"
               "/history 与 /api/audits 可查审计编号，证明 RDS 真的在存；\n"
               "/api/audit 返回 audit_id + fingerprint + 解读，可批量评测。",
               fr(34), INK2, 1350, 54)
    # 上一段 3 行 × 54 = 162，从 1220 起占到 1382；这里必须 ≥1390，
    # 否则会和第 3 行叠在一起（2026-11-04 目检发现的实际缺陷）。
    text_block(d, M, 1400, "本地 OCR（macOS Vision）：图片不出本机；识别草稿先过 critic，需核对比例高时先校对再审计。",
               fr(32), INK2, 1350, 44)
    # 右：六张卡
    cards = [
        ("RDS PostgreSQL", "审计摘要落库\nsrc/store.py；失败降级 SQLite"),
        ("DCS Redis", "缓存 / 限流 / 任务状态\nsrc/cache.py；失败降级进程内"),
        ("ModelArts Studio", "Qwen-VL 解析 + 文本解读\nsrc/llm.py；接地校验，失败退回模板"),
        ("OBS", "原始单据与报告存储\n预签名 URL，原件不入库"),
        ("ECS + Nginx", "HTTPS 公网入口\n或 AI 开发者空间沙箱"),
        ("CodeArts 码道", "开发五环节留痕\n需求→生成→构建→修复→部署"),
    ]
    x0, y0 = 1700, y - 10
    for i, (t, b) in enumerate(cards):
        col = i % 2
        row = i // 2
        x = x0 + col * 1050
        yy = y0 + row * 350
        d.rectangle((x, yy, x + 1000, yy + 310), fill=WHITE, outline=LINE, width=2)
        d.text((x + 30, yy + 26), t, font=fb(42), fill=INK)
        text_block(d, x + 30, yy + 96, b, fr(32), INK2, 940, 46)
    d.rectangle((M, 1840, W - M, 1975), fill=(14, 16, 20))
    text_block(d, M + 40, 1860,
               "状态口径：RDS/OBS 已开通；Redis 创建接口需控制台；MaaS 代码就绪、Key 待开通；"
               "ECS 受余额限制，公网用开发者空间 + DevBridge（72h，可重建）。",
               fr(34), WHITE, W - 2 * M - 80, 48)
    footer(d, 10)
    return im


def p12_onesentence():
    im = Image.new("RGB", (W, H), DARK)
    d = ImageDraw.Draw(im)
    d.text((M, 150), "11  一句话", font=fb(46), fill=AMBER)
    text_block(d, M, 300, "装修报价的问题不是看不懂，\n是没有坐标系。",
               fb(120), WHITE, 3200, 150)
    text_block(d, M, 680, "我们给装修报价，建了一套可计算的坐标系。",
               fb(86), AMBER, 3200, 110)
    d.line((M, 870, W - M, 870), fill=(70, 70, 70), width=3)
    stats = [("119", "工序概念（目标 200）"), ("13", "条审计规则"), ("388", "同义别名"),
             ("5 / 603", "真实单据 / 工序行"), ("243", "个单元测试")]
    for i, (big, lab) in enumerate(stats):
        x = M + i * 700
        d.text((x, 960), big, font=fb(110), fill=AMBER)
        d.text((x, 1100), lab, font=fr(34), fill=(190, 190, 190))
    d.line((M, 1250, W - M, 1250), fill=(60, 60, 60), width=2)
    d.text((M, 1330), "开源仓库：gitee.com/Cwt66/zhuangmingbai", font=fr(42), fill=(200, 200, 200))
    d.text((M, 1400), "公网展示：OBS 永久复验页（不会失效）；可交互 Demo 按 SOP 5 分钟重建", font=fr(38), fill=(150, 150, 150))
    d.text((M, 1470), "联系：【队长邮箱】", font=fr(38), fill=(150, 150, 150))
    d.text((M, 1900), "【学校】·【队名】   装明白 2026.11", font=fr(34), fill=(120, 120, 120))
    footer(d, 12, dark=True)
    return im


def p13_onepager():
    im, d, y = new_page("一页版作品介绍", "装明白 · 可计算审计",
                        "把现实里数百种模糊叫法，映射到 119 个标准概念组成的坐标轴；判断交给可解释的规则。")
    # 左栏
    d.text((M, y + 10), "核心设计思路", font=fb(40), fill=AMBER)
    text_block(d, M, y + 70, "问题三层：工序层（不知道要做什么）· 语言层（同一工序五种叫法）· 证据层（手机拍的脏单据）",
               fr(34), INK2, 1650, 50)
    items = [("01  工序轴对齐 WUA", "119 概念 / 388 别名；整份真实单据对齐 87.4%"),
             ("02  审计规则 DSL", "13 条规则覆盖漏项 / 重复 / 口径 / 算术 / 对账"),
             ("03  可信度分级", "证据强度分（非概率）；三档处置，低分不进钱")]
    yy = y + 220
    for t, b in items:
        d.text((M, yy), t, font=fb(42), fill=INK)
        text_block(d, M, yy + 62, b, fr(32), INK2, 1650, 46)
        yy += 180
    # 右栏
    rx = 1950
    d.text((rx, y + 10), "技术架构 · 五层流水线", font=fb(40), fill=AMBER)
    layers = [("01 感知层", "MaaS Qwen-VL / OCR / file → 行项 JSON"),
              ("02 坐标系层", "同义、上下位、单位换算，归一到工序轴"),
              ("03 判断层", "13 条规则，判断不经过大模型"),
              ("04 可信层", "证据强度 + 三档处置"),
              ("05 表达层", "报告 / 问询单 / 审计包 / 校对台")]
    yy = y + 80
    for t, b in layers:
        d.rectangle((rx, yy, W - M, yy + 170), fill=WHITE, outline=LINE, width=2)
        d.text((rx + 30, yy + 22), t, font=fb(38), fill=INK)
        d.text((rx + 30, yy + 86), b, font=fr(30), fill=INK2)
        yy += 186
    d.text((M, 1450), "可量化", font=fb(38), fill=AMBER)
    text_block(d, M, 1510, "5 份真实单据 / 603 行 · auto 精确率 0.833 · 243 个测试 · 242 例注入 · 59KB 审计包离线复算",
               fr(32), INK2, 1600, 44)
    d.text((M, 1600), "落地", font=fb(38), fill=AMBER)
    text_block(d, M, 1660, "当前 0 个真实用户 → 30 天内 2–3 个家庭试点 → 社区/物业批量 / 装企透明报价入口",
               fr(32), INK2, 1600, 44)
    # 底栏
    d.rectangle((M, 1780, W - M, 1900), fill=(14, 16, 20))
    d.text((M + 40, 1810), "CodeArts 码道  ·  MaaS  ·  RDS PostgreSQL  ·  DCS Redis  ·  OBS  ·  ECS",
           font=fb(38), fill=WHITE)
    d.text((M, 1950), "不判断贵不贵，只判断漏没漏、重没重；低分结论不进核减金额。  MIT  ·  gitee.com/Cwt66/zhuangmingbai",
           font=fr(32), fill=MUTED)
    footer(d, 13)
    return im


def p14_value():
    im, d, y = new_page("12  应用价值", "先把「省下的钱」变成「可核对的数字」",
                        "价值 = 重复剔除 + 可计价漏项；风险敞口单列，不承诺省钱。")
    # 三列
    cols = [
        ("谁在用", "第一次装修的年轻人；替父母把关的子女。场景：拿到 2–4 份报价，看不懂、不敢签、不会砍价。"),
        ("拿到什么", "可核对、可溯源、可复现的审计报告；逐条问询单；审计包可离线复算。"),
        ("怎么落地", "3 个家庭试点 → 社区/物业批量 → 装企透明报价入口。单次 9.9–29.9 元，B 端按项目。"),
    ]
    for i, (t, b) in enumerate(cols):
        x = M + i * 1180
        d.rectangle((x, y + 10, x + 1100, y + 380), fill=WHITE, outline=LINE, width=2)
        d.rectangle((x, y + 10, x + 1100, y + 16), fill=AMBER)
        d.text((x + 34, y + 50), t, font=fb(52), fill=INK)
        text_block(d, x + 34, y + 140, b, fr(36), INK2, 1030, 52)
    # 案例数字
    d.text((M, y + 450), "一笔账：最低价不等于最低成本", font=fb(52), fill=INK)
    rows = [("A 规范型", "86,498", "86,898", "—"),
            ("B 低价引流型", "59,902", "82,066", "6,100–7,300"),
            ("C 高价项全型", "100,146", "96,978", "—")]
    ty = y + 540
    d.text((M, ty), "公司", font=fb(34), fill=MUTED)
    d.text((M + 600, ty), "报价", font=fb(34), fill=MUTED)
    d.text((M + 1100, ty), "补漏/剔重后真实成本", font=fb(34), fill=MUTED)
    d.text((M + 2100, ty), "风险敞口", font=fb(34), fill=MUTED)
    d.line((M, ty + 50, W - M, ty + 50), fill=INK, width=3)
    yy = ty + 80
    for a, b, c, e in rows:
        d.text((M, yy), a, font=fb(38), fill=INK)
        d.text((M + 600, yy), b, font=fb(38), fill=INK2)
        d.text((M + 1100, yy), c, font=fb(38), fill=INK)
        d.text((M + 2100, yy), e, font=fb(38), fill=AMBER if e != "—" else MUTED)
        d.line((M, yy + 70, W - M, yy + 70), fill=LINE, width=2)
        yy += 94
    d.text((M, y + 960), "试点怎么设计（30 天）", font=fb(48), fill=INK)
    steps = [("01", "找人", "亲友/同事中 2–3 个近期要装修、还没签合同"),
             ("02", "介入", "拿到 2–4 份报价，签合同前跑一次审计"),
             ("03", "留证", "记录：提示项 / 实际问询 / 最后核减或补充的金额")]
    for i, (num, t, b) in enumerate(steps):
        x = M + i * 1180
        d.text((x, y + 1040), num, font=fb(40), fill=AMBER)
        d.text((x + 80, y + 1036), t, font=fb(44), fill=INK)
        text_block(d, x, y + 1100, b, fr(32), INK2, 1050, 44)
    d.rectangle((M, 1840, W - M, 1975), fill=(14, 16, 20))
    text_block(d, M + 40, 1860,
               "B 表面比 A 低 26,596 元；补齐 17 处漏项、计入水电敞口后反超 A 1,268–2,468 元。"
               "真实单据还抓出 11,711 元对账差。诚实边界：目前 0 个真实用户，下一步做 2–3 个家庭试点。",
               fr(34), WHITE, W - 2 * M - 80, 48)
    footer(d, 14)
    return im


def p15_roadmap():
    im, d, y = new_page("13  路线图", "从「能跑」到「有人用」：30 / 90 / 365 天",
                        "先解决「用户第一步就失败」，再解决「结论不能直接用」，最后才是规模化。")
    phases = [
        ("30 天", "能演示", ["MaaS/OCR 额度恢复，18 张照片跑通", "3 分钟演示视频 + 公网地址栏", "报名 + 队伍信息（11/30 截止）"], "11/30"),
        ("90 天", "有人用", ["2–3 个真实家庭试点（签约前）", "30 份标注集，双人盲标 κ≥0.8", "PDF 导出 + 拍照引导"], "2027-02"),
        ("365 天", "可复制", ["10–30 个家庭 / 1 家装企试点", "汽修第二行业真实验证", "社区/物业批量入口"], "2027-11"),
    ]
    for i, (when, title, items, due) in enumerate(phases):
        x = M + i * 1180
        d.rectangle((x, y + 10, x + 1100, y + 700), fill=WHITE, outline=LINE, width=2)
        d.rectangle((x, y + 10, x + 1100, y + 16), fill=AMBER if i == 0 else (200, 200, 200))
        d.text((x + 34, y + 40), when, font=fb(72), fill=AMBER if i == 0 else INK2)
        d.text((x + 34, y + 140), title, font=fb(52), fill=INK)
        yy = y + 240
        for it in items:
            d.text((x + 34, yy), "→", font=fb(34), fill=AMBER)
            text_block(d, x + 80, yy, it, fr(34), INK2, 960, 46)
            yy += 130
        d.text((x + 34, y + 610), "节点 " + due, font=fb(34), fill=MUTED)
    # 底部指标
    kpis = [("30 份", "标注集（当前 2 份完整）"), ("3 个", "真实家庭试点（当前 0）"),
            ("≥0.80", "auto 精确率/召回率目标"), ("50+", "开源 star（当前 0）")]
    for i, (big, lab) in enumerate(kpis):
        x = M + i * 900
        d.text((x, 1380), big, font=fb(80), fill=INK)
        d.text((x, 1470), lab, font=fr(32), fill=MUTED)
    d.line((M, 1560, W - M, 1560), fill=LINE, width=2)
    gates = [("Gate 11/30", "报名 + 队伍信息 + 视频脚本就绪"), ("Gate 12/28", "初赛材料：PPT / 技术文档 / Demo 可跑"),
             ("Gate 2027-03", "国赛：真实试点 ≥3、照片端到端跑通、star ≥20")]
    for i, (a, b) in enumerate(gates):
        x = M + i * 1180
        d.text((x, 1600), a, font=fb(38), fill=AMBER)
        text_block(d, x, 1650, b, fr(32), INK2, 1050, 44)
    text_block(d, M, 1845, "止损：照片解析始终不稳 → 退回「PDF/Excel 优先」，明确定位为装企电子报价单审计；"
                           "试点找不到 → 用公开晒单「预算 vs 决算」做事后验证，并在材料里写明局限。",
               fr(32), INK2, W - 2 * M, 44)
    footer(d, 15)
    return im


def p16_team():
    im, d, y = new_page("14  团队", "三个人，一条流水线",
                        "算法 / 工程 / 产品各一人，交叉复核；导师把关边界。")
    roles = [
        ("算法与评测", "本体 / 规则 / 消融 / 标注", "负责「判定对不对」：规则、本体、黄金标注、消融实验。"),
        ("工程与云原生", "感知 / RDS / Redis / 部署", "负责「跑得稳不稳」：provider、持久化、缓存、部署与 /health。"),
        ("产品与材料", "场景 / 报告 / 答辩", "负责「有没有人用」：问询单、报告、试点、视频与答辩。"),
    ]
    for i, (t, sub, b) in enumerate(roles):
        x = M + i * 1180
        d.rectangle((x, y + 10, x + 1100, y + 330), fill=WHITE, outline=LINE, width=2)
        d.text((x + 34, y + 40), t, font=fb(50), fill=INK)
        d.text((x + 34, y + 110), sub, font=fr(32), fill=AMBER)
        text_block(d, x + 34, y + 180, b, fr(34), INK2, 1030, 48)
    # 协作机制
    d.text((M, y + 420), "我们怎么避免「一个人的判断变成全队的结论」", font=fb(52), fill=INK)
    mech = [
        ("冻结指纹", "三份单据预测 sha256，改一个字就漂移"),
        ("标注先行", "先标注后跑引擎，防污染；第二人盲标"),
        ("失败降级", "DB/Redis/模型失败，页面标注，不装成功"),
        ("每条可反驳", "行号 + 基准 + 公式，评委可拿原文反驳"),
    ]
    for i, (t, b) in enumerate(mech):
        x = M + (i % 4) * 900
        d.text((x, y + 520), t, font=fb(40), fill=INK)
        text_block(d, x, y + 580, b, fr(30), INK2, 800, 42)
    d.text((M, y + 760), "每周节奏", font=fb(48), fill=INK)
    text_block(d, M, y + 830,
               "周一：跑 check_all.sh + 看五份冻结指纹 → 周三：只改一个变量并出一组对照数字 → "
               "周五：把新增结论逐条回原文核实，核不掉的降档。\n"
               "原则：不拿「我觉得」进材料；每个数字都要能由脚本重跑，或由第二个人独立核对。",
               fr(32), INK2, 3000, 46)
    d.rectangle((M, 1780, W - M, 1940), fill=(14, 16, 20))
    d.text((M + 40, 1805), "参赛队：【学校】·【队名】", font=fb(42), fill=WHITE)
    d.text((M + 40, 1870), "队员：【姓名】【姓名】【姓名】    指导教师：【姓名】    联系：【队长邮箱】",
           font=fr(34), fill=(200, 200, 200))
    footer(d, 16)
    return im


# ---------------------------------------------------------------- compose
def build_images():
    os.makedirs(OUT, exist_ok=True)
    pages = {
        "s01": p01_cover, "s05": p05_ontology, "s06": p06_rules, "s09": p09_eval,
        "s10": p10_cloud, "s12": p12_onesentence, "s13": p13_onepager,
        "s14": p14_value, "s15": p15_roadmap, "s16": p16_team,
    }
    for name, fn in pages.items():
        im = fn()
        im.save(os.path.join(OUT, name + ".png"))
        print("drew", name)
    # 其余页沿用原图（2/3/4/7/8/11），只复制
    src_dir = os.path.join(os.path.dirname(os.path.dirname(HERE)), "装明白_校赛材料", "_slides")
    for name in ["s02", "s03", "s04", "s07", "s08", "s11"]:
        src = os.path.join(src_dir, name + ".png")
        if not os.path.exists(src):
            raise SystemExit("缺原图：" + src)
        Image.open(src).convert("RGB").save(os.path.join(OUT, name + ".png"))


def compose():
    files = sorted(glob.glob(os.path.join(OUT, "s*.png")))
    if len(files) != 16:
        raise SystemExit("预期 16 页，实际 %d" % len(files))
    ims = [Image.open(f).convert("RGB") for f in files]
    pdf = os.path.join(HERE, "装明白_国奖版_16页.pdf")
    ims[0].save(pdf, "PDF", resolution=288.0, save_all=True, append_images=ims[1:])
    prs = Presentation()
    prs.slide_width = Emu(int(13.3333 * 914400))
    prs.slide_height = Emu(int(7.5 * 914400))
    blank = prs.slide_layouts[6]
    for f in files:
        slide = prs.slides.add_slide(blank)
        slide.shapes.add_picture(f, 0, 0, width=prs.slide_width, height=prs.slide_height)
    prs.core_properties.title = "装明白 · 国奖版作品介绍"
    prs.core_properties.author = "装明白"
    prs.save(os.path.join(HERE, "装明白_国奖版_16页.pptx"))
    # 一页版
    one = os.path.join(HERE, "装明白_一页版.pdf")
    ims[12].save(one, "PDF", resolution=288.0)
    Image.open(files[12]).save(os.path.join(HERE, "装明白_一页版.png"))
    print("composed", pdf)
    print("composed", one)


if __name__ == "__main__":
    build_images()
    compose()
