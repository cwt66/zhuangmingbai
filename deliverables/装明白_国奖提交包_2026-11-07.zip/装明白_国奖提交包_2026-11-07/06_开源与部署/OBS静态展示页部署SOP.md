# OBS 静态展示页部署 SOP（永久公网地址）

> 目的：解决「DevBridge 隧道 72h 失效」这个资格链上的缺口。
> 交互式 Demo 仍走 AI 开发者空间；**展示页与证据材料**托管在华为云 OBS，不会随沙箱释放。
> 首次部署并验证：**2026-11-05 15:00 CST**，四项公网访问均 200。
>
> **2026-11-07 状态更新**：OBS 的 AK 已被服务端判为失效（`InvalidAccessKeyId`），
> 现有对象仍是 `8e49f8d` 快照，无法覆盖更新。**当前公网以 GitHub Pages 为主**：
> `https://cwt66.github.io/zhuangmingbai/`（复验页 `/verify/`、回放 `/replay/`、PDF）。
> 换到新 AK 后按本文第 3 节重传即可，两处内容应保持一致。

---

## 1. 已上线的地址（可直接写进作品信息表「作品展示」）

| 用途 | 公网地址 | 验证 |
|---|---|---|
| **评委 5 分钟复验页**（HTML，10 页） | `https://zmb-quotes-20261029.obs.cn-north-4.myhuaweicloud.com/verify/index.html` | 200 `text/html` |
| 10 页 PDF 版 | `https://zmb-quotes-20261029.obs.cn-north-4.myhuaweicloud.com/verify/装明白_评委复验页_10页.pdf` | 200 `application/pdf` |
| **审计回放页**（可点，5 单 / 86 条结论） | `https://zmb-quotes-20261029.obs.cn-north-4.myhuaweicloud.com/replay/index.html` | 200 `text/html` |
| 封面截图（README 用） | `https://zmb-quotes-20261029.obs.cn-north-4.myhuaweicloud.com/verify/deck-cover.png` | 200 `image/png` |
| 架构页截图（README 用） | `https://zmb-quotes-20261029.obs.cn-north-4.myhuaweicloud.com/verify/deck-architecture.png` | 200 `image/png` |

> 中文文件名在 Markdown 里建议写百分号编码；或直接复制上面浏览器地址栏里的编码串。

**口径（必须写清）**：这是**静态展示页**，不是可交互系统。
可交互 Demo 仍是 `python3 -m uvicorn main:app` / 开发者空间沙箱 + DevBridge。
不要把静态页说成「云上部署的应用」，评委一问就穿帮。

---

## 2. 桶与权限

| 项 | 值 |
|---|---|
| 区域 | `cn-north-4` |
| 桶 | `zmb-quotes-20261029`（2026-10-29 创建，部署前为空桶） |
| 公开方式 | **仅对上传的对象设置 `-acl=public-read`**，没有开放桶策略、没有列出权限 |
| 隐私 | 桶里只放展示页与截图；**不放任何真实单据、CSV、AK/SK、队伍信息** |

上传前先确认桶里没有敏感文件：

```bash
~/.local/hcloud/hcloud obs ls obs://zmb-quotes-20261029 -i=$AK -k=$SK -e=$EP
```

---

## 3. 重新上传（改了 HTML 之后）

```bash
cd /Users/cwt/WorkBuddy/ICT
AK=<你的AK> SK=<你的SK> EP=https://obs.cn-north-4.myhuaweicloud.com

~/.local/hcloud/hcloud obs cp \
  "国奖提交包/02_作品介绍PPT/装明白_评委复验页.html" \
  "obs://zmb-quotes-20261029/verify/index.html" \
  -acl=public-read -u -i=$AK -k=$SK -e=$EP
```

审计回放页用同一条命令（源文件由 `python3 scripts/build_replay.py` 生成）：

```bash
~/.local/hcloud/hcloud obs cp \
  "国奖提交包/06_开源与部署/装明白_审计回放.html" \
  "obs://zmb-quotes-20261029/replay/index.html" \
  -acl=public-read -u -i=$AK -k=$SK -e=$EP
```

`-u` 表示覆盖同名对象；`-acl=public-read` 必须带，否则新对象默认是私有的。

> 密钥只写在本地终端环境变量或 `~/.obsutilconfig`，**不要写进仓库或材料**。

---

## 4. 展示页怎么来的（对应「基于已有智能体和 Skills」）

`装明白_评委复验页.html` 按本地 `skills/frontend-slides`（`zarazhangrui/frontend-slides`，**MIT**）的规范生成：

- 用了：固定 1920×1080 舞台、整页等比缩放、零依赖单文件、`viewport-base.css` 全文内联、
  `.active/.visible` 切页、错峰显现、可见网格与不对称分栏、打印样式与 `prefers-reduced-motion`；
- 没用：任何 HTML/CSS/JS 模板文件的复制；`skills/guizang-ppt-skill`（**AGPL-3.0**）一行代码都没碰。

**两处刻意偏离**（写在 HTML 头部注释里）：
1. 不引外部 Web Font——提交包要能离线双击打开，任何 CDN 都是失败点；改用系统中文衬线 + 黑体搭配；
2. 不做表演性动效——这是复验文档，可读性优先。

验证方式：本机 headless Chromium 逐页截图 10 张，程序化检测溢出 + 总览目检；
第 4、9 页曾出现说明文字压页脚，已通过压缩表格密度与删冗余文字修掉（不是缩小字号硬塞）。

产物：`装明白_评委复验页.html` · `装明白_评委复验页_10页.pdf`（1.43MB，10 页）。

---

## 5. 与提交包其它材料的关系

| 材料 | 定位 |
|---|---|
| 本页（静态 HTML/PDF） | 评委 5 分钟快速复验，**永久可访问** |
| `02_作品介绍PPT/装明白_国奖版_16页.pdf` | 16 页正式作品介绍，离线提交 |
| `03_演示视频/` | 3 分钟实时交互演示（待录） |
| AI 开发者空间 + DevBridge | 可交互云上 Demo（72h，可 5 分钟重建） |

四者互补，不互相替代；材料里不要混着说。
