# v0.5.0 · 国奖版 Release Notes

> **版本范围说明**：本文件描述 v0.5.0 发布快照 `2391a0a`（**105 测试**），是历史版本说明，
> 不随主线更新。在线仓库 `main` 已到 `501b610`（**145 测试**，新增两版对比、审计回放页、守门、增项预测、
> 服务端 PDF 等），判定口径未变（三份冻结指纹逐字节一致）。
> 对外引用测试数时，以 `09_证据附录/评测数字总表.md` 为准。

> 发布日期：2026-11-02 ｜ commit：`2391a0a` ｜ 许可：MIT

## 一句话

在 v0.4 云原生/接地校验的基础上，补上**本地感知**与**质量门**：
macOS Vision 本地 OCR（图片不出本机）、识别草稿 critic + 人工校对、
用户反馈闭环、评测门禁。

## 新增

### 本地感知（v0.5）
- **macOS Vision 本地 OCR**（`scripts/vision_ocr.m` + `src/vision_ocr.py`）：图片不出本机；
  表格重建 + critic（缺字段/量价不符/低置信）。
- **识别草稿 → 人工校对 → 审计**：`/perceive` 在需核对比例 >35% 时停下来，改完 CSV 再审计。
- **评测门禁**（`eval/gate.py`）：auto P/R <0.75、all R <0.90、注入 <230、消融 L2 <0.75 即失败。

### 可审计 Excel（v0.5）
- **零依赖 XLSX 导出**（`src/xlsx.py`）：总览 / 漏项 / 重复 / 风险 / 对账 / 说明 6 个 sheet；
  金额是数值单元格，可继续求和；`/demo.xlsx`、`/real.xlsx`、`POST /audit.xlsx`。
- 上传页增加「下载 Excel」按钮；样例报告页可直接下载。

### 云原生
- **RDS PostgreSQL**（`src/store.py`）：审计摘要/单据/指纹/反馈落库；`/history`、`/report/{id}`、
  `/api/audits` 可查；psycopg 可选，连不上自动降级 SQLite，`/health` 如实显示。
- **DCS Redis**（`src/cache.py`）：审计结果缓存、IP 限流、任务状态；连不上自动降级进程内。
- **MaaS 表达层**（`src/llm.py`）：只转写规则事实；输出接地校验，事实外数字拒收；
  调用失败/无 Key 退回确定性模板，页面标注来源。
- **隐私与注入防护**（`src/privacy.py`）：发送前脱敏；不可信文本隔离；注入识别。
- **本地云原生栈**（`docker-compose.yml`）：PostgreSQL + Redis + App，无华为云账号也能验证。

### 评测
- **黄金标注评测**（`eval/golden_eval.py`）：auto/all 两档 + Wilson 95% CI + 错误明细。
- **消融实验**（`eval/ablation.py`）：L0 仅精确匹配 → L3 范围声明，逐级证明组件贡献。
- **隐私扫描**（`scripts/pii_scan.py`）：CI 硬门槛。
- **一键自检**（`scripts/check_all.sh`）：105 测试 + 评测门禁 + 注入 + 指纹 + 隐私。
- **CI**：GitHub Actions；PR 模板要求更新指纹与评测。

### 文档
- `docs/ARCHITECTURE.md`、`docs/BENCHMARK.md`、`docs/ROADMAP.md`、`SECURITY.md`、`CONTRIBUTING.md`。

## 修复

- `/perceive` 页面曾渲染成首页（`__BODY__` 占位符未替换）——真实 Demo 缺陷。
- 缓存内存实现 `Lock` 自锁死（`rate_limit` 持锁调用 `_mem_get`）→ `RLock`。
- 解读把 `missing["name"]` 当字段（实际是 `concept`），导致 `None`。
- PDF 用例在无 `pypdf` 环境下误报 → skip + 加入 requirements。

## 口径变化

- 真实单据 5 份 / **603 行工序明细 + 11 行汇总**；翡翠台 123 行（+8 汇总），124㎡ 65 行（+3 汇总）。
- 测试 90 → **105**；注入 **242/242**；三份冻结指纹不变；三单回归 400 / 22,164 / 3,168 不变。

## 升级注意

- 新增可选依赖 `psycopg[binary]`、`redis`、`pypdf`；不装也能跑（自动降级/跳过 PDF）。
- `DATABASE_URL` / `REDIS_URL` 未配置时行为与 v0.3 相同（SQLite + 内存）。
- 若从 v0.3 升级，`/health` 返回结构新增 `db` / `cache` / `llm` 三段，旧客户端需忽略未知字段。

## 验证

```bash
bash scripts/check_all.sh
# 105 tests OK (skipped=1)
# 三指纹一致
# 隐私扫描 [OK]
```
