# 部署与复现 SOP（评委/队友都能照做）

> 目标：从 clone 到「公网可访问 + `/health` 全绿」，最多 30 分钟。
> 四条路径，按可靠性排序：**本地 → 离线包 → Docker Compose → 华为云**。

---

## 路径 A：本地（5 分钟，最稳）

```bash
git clone https://gitee.com/Cwt66/zhuangmingbai.git
cd zhuangmingbai
python3 -m pip install -r requirements.txt
python3 -m uvicorn main:app --host 127.0.0.1 --port 8000
```

验证：

```bash
curl -s localhost:8000/health | python3 -m json.tool
# status=ok；db.kind=sqlite；cache.kind=memory；llm.enabled=false（无 Key 时）
```

打开：`/` 上传、`/demo` 三单、`/real` 真实单据、`/review` 校对、`/inquiry` 问询单、`/history` 历史。

**截图/录屏**：首页、`/demo` 报告、`/history`、`/health`。

---

### 路径 A+：本地 OCR（macOS，可选，10 分钟）

```bash
bash scripts/build_vision_ocr.sh
python3 scripts/ocr_vision.py /path/to/报价单.jpg --out out/quote_vision.csv
# 或在 Web 里：/perceive 上传照片 → 识别草稿 → 校对 CSV → /vision/audit
```

- 仅 macOS；图片不出本机；中文可能有错字，**必须校对**。
- 其他平台会自动跳过，`/health` 显示 `vision.available=false`。

## 路径 B：离线包（断网，2 分钟）

```bash
unzip 装明白_离线演示包.zip
cd zhuangmingbai
bash run_offline.sh
# 生成 out/audit_report.html，双击打开
python3 -m unittest discover -s tests   # 可选：331 个测试
```

离线包不依赖云、不依赖第三方包；用于答辩现场断网兜底。

---

## 路径 C：Docker Compose（验证 RDS/Redis 逻辑，10 分钟）

前提：Docker Desktop / Docker Engine + Compose。

```bash
cp .env.example .env       # 可不填 Key
docker compose up --build
curl -s localhost:8000/health | python3 -m json.tool
# 期望：db.kind=postgres；cache.kind=redis
```

说明：本机当前**没有 Docker**，此路径未在本机验证；静态审查通过（Dockerfile 分层、
标准库健康检查、compose 依赖 healthcheck）。**材料里不要写「已验证 Docker 构建」**，
写「提供 compose，未在本机验证」。

---

## 路径 D：华为云（正式评审用，20–30 分钟）

### D1. 开通 RDS PostgreSQL

1. 控制台 → 数据库 → RDS for PostgreSQL → 购买（最小规格即可，1C2G）；
2. 记下内网地址、端口、库名、用户名；
3. 安全组放行 ECS/沙箱所在网段；
4. 连接串：`DATABASE_URL=postgresql://user:pass@host:5432/zmb`。

### D2. 开通 DCS Redis

1. 控制台 → 分布式缓存服务 DCS → 购买 Redis（最小规格）；
2. 记下内网地址/端口/密码；
3. 连接串：`REDIS_URL=redis://:password@host:6379/0`。

> 注意：Redis 的创建接口在当前命令行与官方 Skills 中不存在，**只能走控制台**；
> 这一条写进材料，不要声称「一键命令行开通」。

### D3. 开通 MaaS（可选，但建议）

1. ModelArts Studio → 领取免费额度 → 创建 API Key；
2. 记下 OpenAI 兼容 base_url 与文本/视觉模型 ID（**以控制台实际列表为准**）；
3. `MAAS_API_KEY=...`、`MAAS_BASE_URL=...`、`MAAS_TEXT_MODEL=...`。

### D4. OBS（可选）

1. 创建桶（私有）；
2. 原始单据/报告用预签名 URL 上传/下载；
3. 桶名/区域写进部署记录。

### D5. 启动应用

```bash
# 方式 1：ECS + systemd（见 deploy/DEPLOY.md）
# 方式 2：AI 开发者空间沙箱（见 docs/开发者空间部署指南.md）
export DATABASE_URL='...'
export REDIS_URL='...'
export MAAS_API_KEY='...'
uvicorn main:app --host 0.0.0.0 --port 8000
```

### D6. Nginx + HTTPS

```bash
# deploy/nginx.conf 已含反代、X-Forwarded-For、8m 上传限制
sudo ln -sf /etc/nginx/sites-available/zhuangmingbai /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

HTTPS 可用 certbot/云证书；答辩期间建议加 IP 白名单或 `limit_req`。

---

## 公网 Demo：DevBridge 隧道（临时，5 分钟）

> 适用于没有 ECS 余额、但需要「公网可访问」的场合。链接 72h 失效，随沙箱释放。

1. 进入华为云 AI 开发者空间，打开终端；
2. 克隆仓库、装依赖、启动：

```bash
git clone https://gitee.com/Cwt66/zhuangmingbai.git
cd zhuangmingbai
python3 -m pip install -r requirements.txt
python3 -m uvicorn main:app --host 0.0.0.0 --port 8080
```

3. 在开发者空间开启 **DevBridge** 端口映射 8080；
4. 拿到 `https://<随机>-8080.devbridge-s2.hwtunnel.com`；
5. 外部验证：

```bash
for p in / /demo /real /review /health; do
  curl -s -o /dev/null -w "$p %{http_code}\n" "https://<域名>$p"
done
```

**坑（实测）**：
- 必须绑 `0.0.0.0`，绑 `127.0.0.1` 会 502；
- 首次访问有安全警告页，点继续；
- 沙箱临时，链接 72h 失效；材料里写「可 5 分钟重建」，不要写成永久地址。

---

## 证据采集清单（提交/答辩用）

| # | 证据 | 怎么拿 | 存哪 |
|---|---|---|---|
| 1 | `/health` 全绿 | `curl /health` | `09_证据附录/` |
| 2 | 公网 5 路由 200 | 上面 for 循环 | `09_证据附录/` |
| 3 | `/history` 有审计编号 | 截图 | `09_证据附录/` |
| 4 | RDS 实例页 | 控制台截图（打码账号） | `05_CodeArts过程资产/` |
| 5 | Redis 实例页 | 控制台截图 | `05_CodeArts过程资产/` |
| 6 | OBS 桶列表 | 控制台截图 | `05_CodeArts过程资产/` |
| 7 | CodeArts 五环节 | 会话截图 + `raw/` 文本 | `05_CodeArts过程资产/` |
| 8 | 仓库首页 + LICENSE | 浏览器截图 | `06_开源与部署/` |

---

## 常见问题

| 现象 | 原因 | 处理 |
|---|---|---|
| `/health` 显示 `sqlite` | `DATABASE_URL` 没生效/连不上 | 检查环境变量、安全组、白名单；看 `degraded` |
| `/health` 显示 `memory` | `REDIS_URL` 没配/连不上 | 同上；不影响审计，只是无限流 |
| 解读显示「规则模板生成」 | 无 `MAAS_API_KEY` 或 `LLM_ENABLED=0` | 正常，不装 AI；配 Key 后自动切换 |
| 照片上传 503 | MaaS/OCR 未开通/额度受限 | 用 PDF/Excel/CSV；或充值后重试 |
| `/perceive` 打开是首页 | 旧版本 bug | 升级到 v0.5.0+（已修） |
| Docker 构建失败 | 无 Docker/网络 | 用路径 A/B；不要写「已验证」 |
