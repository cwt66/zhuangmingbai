# -*- coding: utf-8 -*-
"""生成《装明白 · 技术白皮书》国奖版 DOCX。"""
import json
import os

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
REPO = os.path.join(ROOT, "zhuangmingbai")
OUT = os.path.join(HERE, "装明白_技术白皮书.docx")
ARCH = os.path.join(ROOT, "装明白_校赛材料", "装明白_技术架构图_4000x2500.png")

INK = RGBColor(0x0A, 0x0A, 0x0A)
INK2 = RGBColor(0x56, 0x60, 0x6C)
ACCENT = RGBColor(0x00, 0x2F, 0xA7)
AMBER = RGBColor(0xB0, 0x7A, 0x22)
MUTED = RGBColor(0x8A, 0x87, 0x7F)


def set_font(run, name="宋体", size=10.5, bold=False, color=None):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    run.bold = bold
    if color is not None:
        run.font.color.rgb = color


def para(doc, text="", size=10.5, color=INK, bold=False, font="宋体",
         align=WD_ALIGN_PARAGRAPH.JUSTIFY, space_after=6, line=1.45, first_indent=None):
    p = doc.add_paragraph()
    p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = line
    if first_indent is not None:
        p.paragraph_format.first_line_indent = Cm(first_indent)
    r = p.add_run(text)
    set_font(r, font, size, bold, color)
    return p


def h1(doc, num, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(16)
    p.paragraph_format.space_after = Pt(8)
    r = p.add_run(("%s  " % num) if num else "")
    set_font(r, "黑体", 12, True, AMBER)
    r2 = p.add_run(text)
    set_font(r2, "黑体", 17, True, INK)
    # 下划细线
    pPr = p._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:color"), "0A0A0A")
    bottom.set(qn("w:space"), "4")
    pbdr.append(bottom)
    pPr.append(pbdr)


def h2(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text)
    set_font(r, "黑体", 12.5, True, INK)


def bullet(doc, text, size=10.5):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.line_spacing = 1.35
    r = p.add_run(text)
    set_font(r, "宋体", size, False, INK)


def shade(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def table(doc, header, rows, widths=None, size=9.5, align_right=()):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    # 跨页时重复表头
    trPr = t.rows[0]._tr.get_or_add_trPr()
    th = OxmlElement("w:tblHeader")
    th.set(qn("w:val"), "true")
    trPr.append(th)
    hdr = t.rows[0].cells
    for i, h in enumerate(header):
        hdr[i].text = ""
        p = hdr[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(h)
        set_font(r, "黑体", size, True, RGBColor(255, 255, 255))
        shade(hdr[i], "0A0A0A")
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT if i in align_right else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_after = Pt(1)
            r = p.add_run(str(val))
            set_font(r, "宋体", size, False, INK)
        if ri % 2 == 1:
            for c in cells:
                shade(c, "F5F4F0")
    if widths:
        for i, w in enumerate(widths):
            t.columns[i].width = Cm(w)
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def caption(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(10)
    r = p.add_run(text)
    set_font(r, "宋体", 9, False, MUTED)


def add_page_number(section):
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("装明白 · 技术白皮书 ｜ 第 ")
    set_font(r, "宋体", 8, False, MUTED)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    run = OxmlElement("w:r")
    t = OxmlElement("w:t")
    t.text = "1"
    run.append(t)
    fld.append(run)
    p._p.append(fld)
    r2 = p.add_run(" 页 ｜ 2026-11")
    set_font(r2, "宋体", 8, False, MUTED)


def load_json(name):
    p = os.path.join(REPO, "out", name)
    if os.path.exists(p):
        return json.load(open(p, encoding="utf-8"))
    return None


def build():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.2)
    sec.top_margin = Cm(2.0)
    sec.bottom_margin = Cm(1.8)
    add_page_number(sec)
    # 默认样式
    style = doc.styles["Normal"]
    style.font.name = "宋体"
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

    # ---------------- 封面
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(70)
    r = p.add_run("第十一届华为 ICT 大赛 · 中国创新赛 · 赛题 1")
    set_font(r, "黑体", 12, True, AMBER)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    r = p.add_run("装明白")
    set_font(r, "黑体", 40, True, INK)
    p = doc.add_paragraph()
    r = p.add_run("装修报价可计算审计 · 技术白皮书")
    set_font(r, "黑体", 22, True, INK)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    r = p.add_run("COMPUTABLE AUDIT FOR RENOVATION QUOTES")
    set_font(r, "宋体", 10, False, MUTED)
    # 分隔线
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "12")
    bottom.set(qn("w:color"), "0A0A0A")
    pbdr.append(bottom)
    pPr.append(pbdr)

    para(doc, "一句话：把现实里数百种模糊叫法映射到 119 个标准概念组成的坐标轴，判断交给可解释的规则，"
              "每条结论带行号、基准、公式与证据强度分。", 12, INK2, False, "宋体", WD_ALIGN_PARAGRAPH.LEFT, 16, 1.6)
    meta = [
        ("版本", "v0.5.0（2026-11-02）"),
        ("代码 commit", "2391a0a"),
        ("作品仓库", "https://gitee.com/Cwt66/zhuangmingbai"),
        ("参赛队", "【学校】·【队名】｜队员：【姓名】【姓名】【姓名】｜指导教师：【姓名】"),
        ("许可", "MIT"),
    ]
    table(doc, ["项", "内容"], meta, widths=[3.2, 12.4], size=9.5)
    para(doc, "本白皮书的所有数字均来自仓库内可重跑脚本（`bash scripts/check_all.sh`）；"
              "标注「计划」的内容不是已完成结果。", 8.5, MUTED, False, "宋体", WD_ALIGN_PARAGRAPH.LEFT)

    doc.add_page_break()

    # ---------------- 摘要
    h1(doc, "", "摘要")
    para(doc, "装明白是一个面向签约前业主的装修报价审计工具。它把 2–4 家装修公司的报价单"
              "（照片/PDF/Excel/CSV）解析为行项，归一到同一套工序本体，再用 13 条可审阅的规则"
              "判断漏项、重复计价、算术、文档对账与口径风险，输出可核对、可溯源、可复现的报告。", first_indent=0.74)
    para(doc, "核心设计原则是「大模型只做理解与表达，判断交给规则」：感知层用视觉模型或华为云表格识别"
              "把脏单据变成结构化行项；判断层零第三方依赖、同一输入同一输出；表达层用 MaaS 文本模型"
              "转写已算好的事实，并对输出做接地校验——出现事实之外的数字即拒收、退回模板。", first_indent=0.74)
    para(doc, "在 5 份真实单据、603 行工序明细上，系统跑通了完整链路；2 份完整黄金标注上，"
              "auto 档漏项精确率 0.833、召回率 0.833（Wilson 95%CI 0.552–0.953）；重复计价 0 误报；"
              "243 个单元测试、242 例注入实验、59KB 审计包可离线复算。", first_indent=0.74)
    para(doc, "边界同样明确：n=2 只作存在性证明；真实照片端到端依赖 MaaS/OCR 额度；当前 0 个真实用户；"
              "置信度是证据强度分，不是概率。这些边界写进材料，也写进产品界面。", first_indent=0.74)

    h1(doc, "01", "问题与需求")
    h2(doc, "1.1 数据：家装是投诉重灾区")
    table(doc, ["事实", "数据", "来源"], [
        ("房屋装修及物业服务类投诉", "2.18 万件", "中国消费者协会《2025 年全国消协组织受理投诉情况分析》"),
        ("“预算不透明、恶意增项”占比", "38.5%", "上海市消保委 2025 年度家装投诉分析"),
        ("户均被动增项", "2.3 万元（合同价 15%–25%）", "上海市消保委 2025"),
        ("老房翻新超支", "超七成业主遭遇，平均 3.8 万元", "上海市消保委/行业协会"),
    ], widths=[4.2, 4.6, 6.8], align_right=(1,))
    para(doc, "这些数字只说明「问题大」，不说明「我们的方案有效」。方案是否有效，看第 4 节的评测。", 9, MUTED)

    h2(doc, "1.2 问题的三层结构")
    bullet(doc, "工序层：业主不知道老房翻新必须做铲墙皮、垃圾清运、门窗保护——漏项因此发生。")
    bullet(doc, "语言层：同一道工序有五种叫法、三种计价单位——重复计价因此隐藏。")
    bullet(doc, "证据层：报价单是照片/PDF/Excel，纸质单据上手写涂改——Excel 进不去，人眼看不过来。")
    para(doc, "因此，问题的本质不是「看不懂」，而是没有坐标系：没有共同单位，就无从谈起贵贱漏重。"
              "把几百种模糊描述映射到统一工序轴，这件事本身就是产品。", first_indent=0.74)

    h2(doc, "1.3 现有方案为什么不够")
    table(doc, ["方案", "能做", "做不到"], [
        ("人工第三方监理", "现场经验判断", "贵（数千元）、滞后（签约后才进场）"),
        ("通用 OCR + 人工核对", "把图片变成文字", "不产生判断；归一与对齐仍靠人"),
        ("RenoPit 类 LLM 直读", "读单据、搜套路、出报告", "结论随模型与联网结果变；同一单跑两次不一样；无行号级证据"),
        ("Excel / 模板", "结构化管理", "进不了脏单据；做不了跨单本体归一"),
    ], widths=[4.0, 5.0, 6.6])
    para(doc, "结论：这是一个「多脏单据 → 统一坐标系 → 可计算审计」的问题。大模型是必需品（感知与表达），"
              "但不能是裁决者（判断必须可复现）。", first_indent=0.74)

    h2(doc, "1.4 外部对标：信任层比识别层更值钱")
    para(doc, "2026-11 对 GitHub 同类项目做了一轮对标：ap-verify 用独立 critic 拒绝自动批准幻觉总额，"
              "InvoiceMind 把「自动批准/升级复核/隔离」做成显式状态机，RenoPit 证明 LLM 直读可以产品化，"
              "GenPark 用地区价格基准直接判「偏高」。我们借了前三者的「信任层 + 人工复核 + 可回放」，"
              "明确不借价格基准——价格不可靠，判错代价不对称。", first_indent=0.74)
    para(doc, "落到 v0.5：感知层加 critic 与草稿校对门，评测加 CI 门禁，报告加反馈闭环。"
              "详见《外部对标与设计取舍》。", 9, MUTED)

    doc.add_page_break()
    h1(doc, "02", "总体架构")
    para(doc, "五层流水线，职责单一，可以分段验证：感知层错了看对齐率，对齐错了看未匹配清单，"
              "判断错了看规则单测，表达错了看接地校验。任何一层出错，都不会被另一层掩盖。", first_indent=0.74)
    if os.path.exists(ARCH):
        doc.add_picture(ARCH, width=Cm(16.2))
        caption(doc, "图 1  装明白总体架构（五层流水线 + 华为云底座）")
    table(doc, ["层", "做什么", "不做什么", "代码"], [
        ("感知层", "照片/PDF/Excel/CSV → 行项 JSON，字段级置信度，逐行算术自校验", "不判断对错", "src/perception.py"),
        ("坐标系层", "119 概念 / 388 别名归一到同一工序轴；同义/上下位/单位换算", "不做结论", "src/pipeline.py / data/ontology_v0.json"),
        ("判断层", "13 条规则：漏项/重复/算术/对账/口径/义务", "不写文案", "src/pipeline.py / data/rules_v0.json"),
        ("可信层", "证据强度分 + 三档处置；低分不进钱", "不改判定", "src/pipeline.py"),
        ("表达层", "报告 / 问询单 / 审计包 / 校对台；模型只转写", "不新增事实", "src/llm.py / src/inquiry.py"),
    ], widths=[2.4, 7.2, 2.8, 3.6])

    h1(doc, "03", "关键模块")
    h2(doc, "3.1 坐标系：把 119 个概念映射到同一根轴")
    para(doc, "本体包含 119 个工序概念、388 个同义别名、8 大类，含同义词、上下位关系、单位换算与"
              "老房/新房差异。对齐采用四级策略：精确（0.98）→ 别名（0.95）→ 模糊（0.62–0.90）→ 包含（0.85）；"
              "都打不中就是「本体缺口」，列清单，不猜。", first_indent=0.74)
    table(doc, ["指标", "结果", "口径"], [
        ("60 个真实项目名对齐", "精确/别名 83.3%，模糊 16.7%，缺口 0%", "eval/eval_alignment.py"),
        ("篱笆整单行项对齐", "111/127 = 87.4%", "中国公开晒单，人工转录"),
        ("124㎡ 整单行项对齐", "62/65 = 95.4%", "小红书公开晒单，人工转录"),
        ("18 条缺口补入", "覆盖 53.3% → 83.3%，缺口清零", "CodeArts 代码生成环节"),
    ], widths=[4.6, 6.6, 4.4])

    h2(doc, "3.2 规则 DSL：13 条，可逐条审阅")
    rules = [
        ("R1", "漏项", "模板必做项 − 实列项（集合差），再做文本证据词二次判定"),
        ("R2", "重复（工艺包含）", "已知工艺包含对，加同分区约束 + scope_hint"),
        ("R3", "重复（同概念多行）", "同概念多行 + 变体判别（部位/规格不同则排除）"),
        ("R4", "口径模糊", "按实结算/暂定/据实/按根/按米，按单据聚合"),
        ("R5", "跨单单位", "同一工序在不同报价里单位不一致"),
        ("R6", "单位异常", "㎡ 报成 m、项数量 >1 等"),
        ("R7", "拆分计价", "材料费 + 人工费被拆成两行"),
        ("R8", "算术", "|合价 − 数量×单价| > 容差"),
        ("R9", "量纲", "数量与单位语义不匹配"),
        ("R10", "管理费率", "管理费/总价 > 阈值；分层后仍扫 summary_rows"),
        ("R11", "规格缺失", "影响计价的规格未写"),
        ("R12", "防水高度", "报价高度低于惯例（1.8m）"),
        ("R13", "文档对账", "明细 + 取费 vs 印刷合计"),
    ]
    table(doc, ["ID", "规则", "判据"], rules, widths=[1.4, 4.0, 10.2])
    para(doc, "规则只依赖本体与模板，不依赖任何价格库——既不判断贵不贵，也不对定价合理性作断言。", 9, MUTED)

    h2(doc, "3.3 可信分级：不只报结论，还报有多少证据")
    para(doc, "证据强度分 s = 0.4×规则强度 + 0.2×解析质量 + 0.2×对齐确定性 + 0.2×模板匹配度。"
              "s ≥ 0.90 自动（进核减金额）；0.60–0.90 建议复核（标黄，写明为什么不确定）；"
              "s < 0.60 转人工（只提示需确认）。低分结论一律不进核减金额。", first_indent=0.74)
    para(doc, "必须说清楚：s 是证据强度的排序信号，不是校准后的概率。我们没有声称「报 90% 就真的对 90%」；"
              "那需要人工标注集拟合校准曲线，当前标注量不足，标为待补。", 9, MUTED)

    h2(doc, "3.4 云原生：RDS / Redis / MaaS 在代码里真的被调用")
    table(doc, ["华为云服务", "承担什么", "代码", "没开通时"], [
        ("RDS for PostgreSQL", "审计摘要、单据、指纹、反馈落库；/history 可回看", "src/store.py", "降级 SQLite，/health 标注"),
        ("DCS for Redis", "审计结果缓存、IP 限流、异步任务状态", "src/cache.py", "降级进程内，/health 标注"),
        ("ModelArts Studio", "Qwen-VL 解析 + 文本解读；接地校验", "src/perception.py / src/llm.py", "报告标注「规则模板生成」"),
        ("OBS", "原始单据与报告存储", "部署手册预签名 URL", "本地临时文件"),
        ("ECS + Nginx", "HTTPS 公网入口", "deploy/", "本地 uvicorn 可演示"),
    ], widths=[3.8, 6.4, 4.0, 3.4])
    para(doc, "一个原则：云服务失败时，产品可以降级，但不能假装成功。/health 会逐项返回 kind、degraded、configured，"
              "评委可以当场核对。", 9, MUTED)

    h2(doc, "3.5 表达层：模型只转写，接地校验拒收幻觉")
    para(doc, "MaaS 文本模型拿到的是已经算好的事实清单（公司、金额、漏项、对账差），只允许做概括、排序、"
              "把结论转成问句。提示词写明「不得新增数字/结论/价格判断」；输出后做接地校验："
              "出现事实清单之外的数字 → 重试一次 → 仍失败则退回确定性模板。", first_indent=0.74)
    para(doc, "页面上永远标注这段解读的来源：MaaS 生成（已接地校验）或规则模板生成。"
              "不把模板伪装成 AI，也不把 AI 的幻觉留在报告里。", first_indent=0.74)

    h2(doc, "3.6 本地 OCR + critic：先承认会看错，再决定能不能用")
    para(doc, "云端 MaaS 需要 Key 与额度，而真实用户的第一步是拍一张报价单。v0.5 增加 macOS Vision "
              "本地 OCR：图片不出机器，输出文本框与坐标；Python 侧按表头推断列、按数量/单价锚点聚行，"
              "再用 critic 检查缺项目名/单位/数量/单价/合价、数量×单价≠合价（2% 容差）、置信度 <0.3。"
              "需核对比例 >35% 时，/perceive 不直接出审计报告，而是进入「识别草稿：先校对，再审计」页面。",
         first_indent=0.74)
    para(doc, "实测一张真实报价单照片：243 个文本框 → 38 行，critic 通过 23 行、需核对 15 行，"
              "32 行可做算术校验、1 行量价不符（3×180=540，OCR 读出 510）。这不是准确率，"
              "是「错误会被抓住、而不是静默进结论」的流程验证。", 9, MUTED)

    doc.add_page_break()
    h1(doc, "04", "评测方法与结果")
    para(doc, "所有数字都可由 `bash scripts/check_all.sh` 重跑；改一个组件，表会变，报告必须跟着变。", 9, MUTED)

    h2(doc, "4.1 数据集")
    table(doc, ["单据", "来源性质", "工序行", "汇总行", "完整黄金标注"], [
        ("上海卓观 · 两房半包", "篱笆网公开晒单", "127", "0", "—"),
        ("花溪北岸 · 5 页施工报价", "公开晒单，照片转录", "120", "0", "—"),
        ("深圳新新 · 诊所装饰", "公开 PDF", "168", "0", "—"),
        ("上海翡翠台 · 老房全案", "公开晒单，照片转录", "123", "8", "✅ 39 项"),
        ("124㎡ · 基础报价单", "小红书公开晒单，照片转录", "65", "3", "✅ 28 项"),
        ("合计", "5 份（4 家装 + 1 工装）", "603", "11", "2 份"),
    ], widths=[5.4, 5.6, 2.2, 2.2, 3.0], align_right=(2, 3))

    h2(doc, "4.2 黄金标注：auto / all 两档并报")
    ge = load_json("golden_eval.json") or {}
    micro = ge.get("micro", {})
    rows = []
    for mode in ("auto", "all"):
        m = micro.get(mode, {})
        rows.append((mode, m.get("tp", "—"), m.get("fp", "—"), m.get("fn", "—"),
                     "%s %s" % (m.get("precision"), m.get("precision_ci")),
                     "%s %s" % (m.get("recall"), m.get("recall_ci"))))
    table(doc, ["档位", "TP", "FP", "FN", "精确率 [95%CI]", "召回率 [95%CI]"], rows,
          widths=[2.2, 1.8, 1.8, 1.8, 4.6, 4.6], align_right=(1, 2, 3))
    para(doc, "auto = 只算 tier=auto 的确定性漏项（进核减金额）；all = 含 review 档（进待确认清单）。"
              "两档并报，是因为「精确率」在两种口径下不同；只报好看的那档就是选择性展示。", 9, MUTED)
    para(doc, "误差明细：feitai 的 FP 为 grout（填缝）、wp_height（防水加高）——模板有、原单确实没单列，"
              "属口径分歧；guijiao124 的 FN 为 interface_agent、primer——被判 review 档，全量档召回 4/4。"
              "not_applicable 的 level_floor（贴砖已含找平）单列，不计 FP。", 9, MUTED)

    h2(doc, "4.3 消融：每一级只加一个组件")
    ab = load_json("ablation.json")
    if ab:
        rows = []
        for stage in ab:
            sid = stage["stage"]["id"]
            name = stage["stage"]["name"]
            for d in stage["docs"]:
                rows.append((sid, name, d["doc"], "%.1f%%" % (d["align_rate"] * 100),
                             d["predicted"], d["tp"], d["fp"], d["fn"],
                             d["precision"], d["recall"]))
        table(doc, ["级", "组件", "单据", "对齐率", "预测", "TP", "FP", "FN", "精确率", "召回率"],
              rows, widths=[1.2, 3.4, 2.6, 2.0, 1.4, 1.2, 1.2, 1.2, 1.6, 1.6],
              align_right=(3, 4, 5, 6, 7, 8, 9), size=8.5)
    para(doc, "读法：L0 召回 1.0、精确率 0.267——把没对齐的行当成没有，是不可用的高召回；"
              "L2 加上文本证据词，feitai auto 精确率升到 0.800；L3 加上范围声明，124㎡ auto 预测 9→3、"
              "漏项金额 5,573→259。坐标系不是形容词，是能把误报压下去的组件。", 9, MUTED)

    h2(doc, "4.4 注入实验：下限校验，不是召回率")
    para(doc, "5 类注入对应 5 条规则，242 个程序已知缺陷，检出 242。它是「规则能否抓到自己定义的缺陷形态」"
              "的下限校验，不是召回率。实验本身抓到两件事：类目级删除后子项仍在，注入真值无效；"
              "诊所 PDF 分页致序号跨页重复，行号无法唯一定位——真产品缺陷，已登记。", 9, MUTED)

    h2(doc, "4.5 感知层闭环：先对账，再判漏项")
    table(doc, ["指标", "原始 OCR", "人工校对"], [
        ("对齐率", "40.0%", "82.9%"),
        ("auto 漏项", "13", "10"),
        ("明细合计", "84,491.70", "153,384.00"),
    ], widths=[6.0, 5.0, 5.0], align_right=(1, 2))
    para(doc, "原始 OCR 少 68,892 元——第 4 页主材区斜拍列错位整段丢失。只跑漏项会拿到「看起来正常」的报告；"
              "先对账再判漏项，是唯一能发现 OCR 丢数据的手段。", 9, MUTED)

    h2(doc, "4.6 与 RenoPit 的对照实验（进行中）")
    para(doc, "协议已预注册（eval/对照实验协议_RenoPit.md），指标为 M1 结论条数、M2 可溯源率、"
              "M3 漏项召回、M4 幻觉数。我方 49 条已自动填表（M2 100% 是结构事实，自证，不可与对手直接比）；"
              "RenoPit 侧 0 条，待按操作卡跑批。没跑就不写数字。", 9, MUTED)

    doc.add_page_break()
    h1(doc, "05", "华为云产品在五环节的使用价值")
    table(doc, ["环节", "码道 CodeArts 做了什么", "可复核的产出"], [
        ("需求理解", "把赛题拆成需求清单与验收标准；把三类审计写成可验收条款", "12 条规则判据→13 条；stage1_requirement.txt"),
        ("代码生成", "按模块描述生成；补本体 18 个概念", "101/221 → 119/286；覆盖 53.3%→83.3%；2 commit / 525 行"),
        ("项目构建", "Dockerfile / .dockerignore / 依赖清单", "人修掉 curl 健康检查；补 docker-compose"),
        ("问题修复", "空 CSV 500→400；其余 17 个真实数据缺陷人工修", "根因写进 commit message；回归测试"),
        ("部署上线", "systemd / Nginx / DEPLOY；RDS/OBS 命令行", "公网 Demo 5 路由 200 存证；5 分钟重建 SOP"),
    ], widths=[2.2, 8.0, 6.4])
    para(doc, "真实观察：免费套餐排队严重，单次会话出现 26 次「模型排队」。所以「AI 开发提效」在本项目里的"
              "真实含义是：省的是写代码的时间，不是等结果的时间。这条写进材料，不藏。", 9, MUTED)

    h1(doc, "06", "安全、隐私与合规")
    bullet(doc, "发送前脱敏：手机号/身份证/邮箱/银行卡/明确标注的姓名与地址；金额与工序不动；脱敏在本地完成。")
    bullet(doc, "提示词注入防护：单据文本是不可信输入，定界符隔离 + 注入识别 + 输出接地校验。")
    bullet(doc, "数据最小化：真实单据来自公开晒单/公开 PDF 或授权；原始照片不入库；仓库 CSV 已扫描无个人信息。")
    bullet(doc, "失败不装懂：感知失败明确报错；模型失败退回模板并标注；DB/Redis 失败降级但 /health 说实话。")
    bullet(doc, "定位：计费核对与信息整理工具；非定价鉴定、非法律意见、非施工验收。")

    h1(doc, "07", "可迁移性：判定能力在数据里")
    para(doc, "引擎不包含装修专有名词；领域知识全部在本体/模板/覆盖率/规则四份 JSON。"
              "汽修迁移实验只换 data/repair/ 下三份 JSON，引擎零改动，跑出：对齐 19/19、漏项 4、重复 1、"
              "算术 1、对账差 30 元、开口条款 2 类。迁移过程中抓出两处隐式领域耦合（onto['u']、_cross_unit），"
              "已修并锁进 7 个测试。", first_indent=0.74)

    h1(doc, "08", "局限与下一步")
    table(doc, ["局限", "现状", "下一步"], [
        ("真实照片端到端", "MaaS 未开通；OCR 额度受限", "额度恢复后跑 18 张照片，字段准确率 ≥85%"),
        ("真实用户", "0 个", "2–3 个家庭试点（签约前介入），记录提示项 vs 实际核减"),
        ("标注规模", "2 份完整黄金标注，单一标注者", "30 份标注集，双人盲标，Cohen's κ ≥0.8"),
        ("置信度校准", "证据强度分，非概率", "标注量足够后拟合校准曲线；当前不声称 ECE"),
        ("云上固定地址", "DevBridge 隧道 72h", "ECS + 域名 + HTTPS，函评期间固定可访问"),
    ], widths=[3.6, 7.0, 6.0])

    h1(doc, "09", "复现")
    para(doc, "环境：Python 3.10+；离线演示不需要网络与第三方包。", 10)
    for line in [
        "git clone https://gitee.com/Cwt66/zhuangmingbai.git",
        "cd zhuangmingbai",
        "bash run_offline.sh            # 三单 → out/audit_report.html",
        "bash scripts/check_all.sh      # 90 测试 + 评测 + 注入 + 指纹 + 隐私",
        "python3 -m uvicorn main:app --host 0.0.0.0 --port 8000",
    ]:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run(line)
        set_font(r, "Consolas", 9.5, False, INK)

    h1(doc, "附录", "数字总表与链接")
    table(doc, ["项", "值", "出处"], [
        ("工序概念 / 同义别名", "119 / 388", "data/ontology_v0.json"),
        ("工序模板", "老房 39 / 新房 28", "data/templates_v0.json"),
        ("审计规则", "13 条", "data/rules_v0.json"),
        ("真实单据 / 工序行", "5 份 / 603 行（+11 汇总）", "data/real/"),
        ("黄金标注", "2 份（39 + 28 项）", "eval/golden_labels_*.csv"),
        ("auto 精确率 / 召回率", "0.833 / 0.833（95%CI 0.552–0.953）", "eval/golden_eval.py"),
        ("all 召回率", "1.000", "eval/golden_eval.py"),
        ("注入实验", "242 / 242（下限校验）", "eval/injection_test.py"),
        ("本地 OCR 流程验证", "224 框 → 38 行；通过 23 / 需核对 15", "scripts/ocr_vision.py"),
        ("可审计 Excel", "6 sheet（总览/漏项/重复/风险/对账/说明）", "src/xlsx.py"),
        ("单元测试", "243 个", "bash scripts/check_all.sh"),
        ("单份审计端到端", "约 89.2ms", "本机实测"),
        ("开源仓库", "https://gitee.com/Cwt66/zhuangmingbai", "MIT"),
    ], widths=[5.6, 7.0, 4.0])
    para(doc, "材料之间数字不一致时，以仓库脚本重跑结果为准。", 9, MUTED)

    doc.save(OUT)
    print("saved", OUT)


if __name__ == "__main__":
    build()
