# -*- coding: utf-8 -*-
"""生成《作品信息收集表》国奖版：保留官方模板，填入最新口径，队伍信息留醒目占位。"""
import os
import shutil
import sys

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SRC = os.path.join(ROOT, "【赛题1-模板1】创新赛-作品信息收集表-学校-队名-队长姓名-手机号 （初赛阶段）.docx")
OUT = os.path.join(ROOT, "国奖提交包", "01_作品信息收集表", "装明白_作品信息收集表_国奖版.docx")


def set_run_font(run, size=10.5, bold=False, color=None):
    run.font.name = "宋体"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)


def clear_cell(cell):
    # 保留第一个段落，删除其余；不整格赋 .text，避免丢格式
    for p in cell.paragraphs[1:]:
        p._element.getparent().remove(p._element)
    p = cell.paragraphs[0]
    for r in list(p.runs):
        r._element.getparent().remove(r._element)
    return p


def write_cell(cell, blocks, size=10.5):
    """blocks: [(text, bold, size, color)]；空字符串表示段内换行。"""
    p = clear_cell(cell)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.line_spacing = 1.15
    first = True
    for text, bold, sz, color in blocks:
        if not first:
            p = cell.add_paragraph()
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.line_spacing = 1.15
        first = False
        run = p.add_run(text)
        set_run_font(run, size=sz, bold=bold, color=color)


INTRO1 = (
    "家装是消费投诉的重灾区。中国消费者协会《2025年全国消协组织受理投诉情况分析》显示，"
    "房屋装修及物业服务类投诉达2.18万件；上海市消保委数据显示，“预算不透明、恶意增项”占38.5%，"
    "户均被动增项2.3万元，约为合同价的15%–25%。问题的本质不是“看不懂”，而是缺少坐标系："
    "同一道工序有五种叫法、三种计价单位，业主无法把多家报价放到同一张表上比较。"
    "现有替代方案也不够：人工第三方监理贵且滞后；OCR只把图片变成文字、不产生判断；通用问答式AI给的意见读得懂却没法复核。"
    "装明白面向签合同前的业主：上传2–4家报价单，输出可核对、可溯源、可复现的审计报告——"
    "谁漏了项、谁重复收钱、谁口径混乱、补漏后真实成本是多少。"
    "系统把119个工序概念、388个同义别名归一到同一根工序轴，判断交给13条可审阅的规则，"
    "每条结论附原表行号、对照基准与计算公式，并给出证据强度分；低分结论不进核减金额，只进待确认清单。"
    "在5份真实单据、603行工序明细上，翡翠台单份auto档召回8/8、精确率0.80；"
    "124㎡基础报价单范围内召回4/4、精确率1.00。同一套引擎只换本体/模板即可审汽修维保单（7个迁移测试），"
    "证明“判定能力在数据里”。我们不判断贵不贵，只判断漏没漏、重没重。"
)

INTRO2 = (
    "本项目以华为云码道CodeArts作为唯一开发底座，把“想法到应用”拆成五个可度量环节，逐环节留痕，可由评委复核。"
    "（1）需求理解：用码道把赛题要求拆成需求清单与验收标准，关键动作是把“三类审计”写成可验收条款——"
    "漏项必须给出模板差集，重复必须给出两处行号，口径必须指出具体措辞，而不是“智能识别增项”这类无法验收的描述。"
    "1轮会话产出12条规则的判据，后扩至13条，采纳13条。"
    "（2）代码生成：按模块描述接口与验收标准由码道生成。git统计：码道提交2个commit、新增525行、覆盖7个文件；"
    "本体由101概念/221别名扩至119/286，对齐覆盖率53.3%→83.3%，可用git revert复现回退。"
    "（3）项目构建：码道生成Dockerfile、.dockerignore与依赖清单；人工复核发现健康检查写curl而slim镜像不含curl，"
    "改为标准库探活，避免容器永远unhealthy；同时补了docker-compose（PostgreSQL+Redis+应用）用于本地验证RDS/Redis逻辑。"
    "构建验证待补：本机无Docker，我们不把“文件写对了”说成“构建通过了”。"
    "（4）问题修复：累计6个CodeArts环节缺陷与17个真实数据缺陷，根因全部写进commit message；"
    "1个由码道单轮修复（空CSV上传500→400），其余由127行真实报价单暴露后人工修复。"
    "（5）部署上线：RDS PostgreSQL与OBS已通过命令行开通；Redis创建接口在当前命令行与官方Skills中不存在，只能走控制台；"
    "ECS因账户余额校验未完成实例创建。已用华为云AI开发者空间+DevBridge隧道跑出HTTPS公网Demo（5路由200，有存证），"
    "链接随沙箱释放，5分钟可重建。"
    "代码层已把RDS/Redis/MaaS真正接进业务：RDS存审计摘要（src/store.py，失败降级SQLite），"
    "Redis做缓存/限流/任务状态（src/cache.py，失败降级进程内），MaaS做照片解析与报告解读（src/llm.py，输出接地校验、失败退回模板）。"
    "价值不在“生成得快”，而在可验证：引擎跑通5份真实单据/603行明细，判出确定性漏项并逐条回原文核实；"
    "243个单元测试、242例注入实验、59KB审计包可离线复算；/health逐项显示db/cache/llm状态，失败不装成功。"
    "安全侧，单据发送模型前先本地脱敏（手机号/身份证/邮箱/银行卡），并对“忽略以上指令”类提示词注入做隔离与识别；"
    "评测侧，黄金标注auto档精确率0.833、召回率0.833（Wilson 95%CI 0.552–0.953），消融实验证明坐标系、证据词、范围裁剪各自贡献。"
)

TECH = (
    "整体技术方案：五层流水线，原则是“大模型只做理解与表达，判断全部交给可解释的规则与计算”。"
    "感知层把照片/PDF/Excel/CSV变成行项JSON（file/MaaS Qwen-VL/华为云表格识别/mock四provider），"
    "逐行做算术自校验；坐标系层把119概念/388别名归一到同一工序轴；判断层13条规则覆盖漏项、重复、算术、对账、口径与义务；"
    "可信层输出证据强度分与三档处置；表达层生成报告、问询单、审计包、校对台与可审计 Excel。"
    "云原生：RDS PostgreSQL存审计摘要（src/store.py，失败降级SQLite）；DCS Redis做缓存/限流/任务状态（src/cache.py，失败降级进程内）；"
    "ModelArts Studio做视觉解析与文本表达（src/perception.py、src/llm.py），表达层输出做接地校验，出现事实外数字即拒收并退回模板。"
    "\n模块1 工序轴对齐（WUA）：精确/别名/模糊/包含四级对齐，含同义词、上下位与单位换算；"
    "老房翻新39项/新房毛坯28项两套模板，支持“报价范围声明→模板裁剪”。指标：篱笆整单111/127=87.4%，124㎡ 62/65=95.4%。"
    "\n模块2 审计规则DSL：13条规则以JSON表达，每条含判据、证据字段与强度；不依赖任何价格库。"
    "消融实验显示：仅精确匹配时auto精确率0.267，加模糊/包含后0.421，加文本证据词后0.800——证明“坐标系”不是形容词。"
    "\n模块3 可信与云原生：证据强度分=规则强度0.4+解析质量0.2+对齐确定性0.2+模板匹配度0.2，≥0.90自动/0.60–0.90复核/<0.60转人工；"
    "低分不进核减金额。审计包59KB，verify.py 30秒离线复算，改一个数字立即FAIL。243个测试覆盖PDF坐标、本地OCR、回归线、对账分层、四项创新与跨领域迁移。"
    "\n可量化效果：5份真实单据/603行明细+11行汇总；黄金标注auto档TP=10/FP=2/FN=2，精确率0.833、召回率0.833（Wilson 95%CI 0.552–0.953）；"
    "all档召回1.000；重复计价0误报；注入实验242/242（下限校验，非召回率）；单份审计端到端约89.2ms，纯规则判定0.33ms。"
)

SHOW = (
    "1. 公网Demo：华为云AI开发者空间+DevBridge隧道（曾有5路由200的存证，链接72h失效；"
    "按开源仓库docs/开发者空间部署指南.md约5分钟重建）。本地一键：python3 -m uvicorn main:app --port 8000。"
    "\n2. 开源仓库：https://gitee.com/Cwt66/zhuangmingbai（MIT；README/使用文档/部署指导/评测脚本齐全）。"
    "\n3. 演示视频：3分钟，按“03_演示视频”逐镜脚本录制后回填链接。"
    "\n4. 技术架构图：装明白_技术架构图_4000x2500.png（随包提交）。"
    "\n5. CodeArts开发实践报告：装明白_校赛材料/CodeArts过程资产.md（五环节原始输出+提交流水）。"
    "\n6. 离线演示包：装明白_离线演示包.zip（断网可跑；解压后 bash run_offline.sh）。"
    "\n7. 可审计 Excel：/demo.xlsx（6 个 sheet：总览/漏项/重复/风险/对账/说明；金额为数值）。"
)


def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    shutil.copyfile(SRC, OUT)
    doc = Document(OUT)
    t = doc.tables[0]
    # 队伍信息：保留醒目占位，便于队长替换；不要在正式提交时留方括号
    write_cell(t.rows[1].cells[1], [("【学校名称】", True, 10.5, (0xC0, 0x00, 0x00))])
    write_cell(t.rows[2].cells[1], [("【队伍名称】", True, 10.5, (0xC0, 0x00, 0x00))])
    for i, label in enumerate(["【指导教师姓名】", "【队员1姓名】", "【队员2姓名】", "【队员3姓名】"]):
        write_cell(t.rows[4].cells[1 + i], [(label, True, 10.5, (0xC0, 0x00, 0x00))])
    write_cell(t.rows[5].cells[1], [("【队长手机号】", True, 10.5, (0xC0, 0x00, 0x00))])
    write_cell(t.rows[6].cells[1], [("【队长邮箱】", True, 10.5, (0xC0, 0x00, 0x00))])
    write_cell(t.rows[10].cells[1], [("装明白——装修报价可计算审计", True, 11, None)])
    write_cell(t.rows[11].cells[1], [("生活应用（家装消费 / 消费者权益保护）", False, 10.5, None)])
    write_cell(t.rows[12].cells[1], [(
        "华为云码道 CodeArts（需求理解→代码生成→项目构建→问题修复→部署上线五环节）；"
        "macOS Vision 本地 OCR（可选，图片不出本机；识别草稿先过 critic 再审计）；"
        "ModelArts Studio（MaaS：Qwen-VL 单据解析 + 文本模型报告解读，输出接地校验）；"
        "RDS PostgreSQL（审计摘要/指纹落库）；DCS Redis（缓存/限流/任务状态）；"
        "OBS（原始单据与报告）；ECS + Nginx + HTTPS（公网部署）；"
        "AI 开发者空间 + DevBridge（临时公网演示）。", False, 10.5, None)])

    write_cell(t.rows[13].cells[1], [
        ("一、方案的背景和价值（≤500字）", True, 11, None),
        (INTRO1, False, 10.5, None),
        ("", False, 6, None),
        ("二、华为云产品在五环节的使用价值（≤1000字）", True, 11, None),
        (INTRO2, False, 10.5, None),
    ], size=10.5)

    write_cell(t.rows[14].cells[1], [
        (TECH, False, 10.5, None),
    ], size=10.5)

    write_cell(t.rows[15].cells[1], [
        (SHOW, False, 10.5, None),
    ], size=10.5)

    # 不在正文加提醒，避免误提交；提醒放在同目录《填写说明与待补清单.md》
    doc.save(OUT)
    print("saved", OUT)

    # 自检：字数（汉字 + 英文/数字词）
    import re
    for name, text in (("介绍1", INTRO1), ("介绍2", INTRO2)):
        han = len(re.findall(r"[\u4e00-\u9fa5]", text))
        words = len(re.findall(r"[A-Za-z0-9][A-Za-z0-9./%\-]*", text))
        print("%s: 汉字 %d + 英文/数字词 %d = %d（限 %s）" % (
            name, han, words, han + words, "500" if name == "介绍1" else "1000"))


if __name__ == "__main__":
    main()
