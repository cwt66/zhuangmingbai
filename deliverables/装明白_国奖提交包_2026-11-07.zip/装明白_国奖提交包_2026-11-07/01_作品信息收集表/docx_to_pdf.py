# -*- coding: utf-8 -*-
"""DOCX → PDF 渲染器（本机无 Word / LibreOffice 时的兜底方案）。

为什么需要它
------------
提交包里的 PDF 原来是另一台机器用 LibreOffice 导的。本机没有 Word、没有
LibreOffice、Pages 被系统权限拦住，所以「改了 DOCX 却重不出 PDF」——
结果就是 DOCX 写 105 个测试、PDF 还写着 97。

排版策略（踩过的坑）
------------------
- `splitInRow=1` 看似能解决「长单元格顶空一整页」，但它与合并单元格冲突：
  拆页后列宽丢失、左侧标签列直接消失。所以不用它。
- 改为：**短行保留表格，长文本行（>300 字）拆成「标签条 + 全宽段落」**。
  这样长内容能在任意位置自然跨页，不会把上一页顶出大片空白。
- 内容与 DOCX 同源，版式按 A4 重算；不追求与 Word 像素级一致。

用法：
    python3 docx_to_pdf.py <input.docx> [output.pdf]
"""
import os
import sys

from docx import Document
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (KeepTogether, Paragraph as RLP, SimpleDocTemplate,
                                Spacer, Table as RLTable, TableStyle)

FONT_CANDIDATES = [
    ("/System/Library/Fonts/Supplemental/Arial Unicode.ttf", "CJK"),
    ("/System/Library/Fonts/Supplemental/Songti.ttc", "CJK"),
    ("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc", "CJK"),
]
FONT = "Helvetica"
LONG_CELL = 300          # 超过这个字数的单元格改成全宽段落
INK = colors.HexColor("#0A0A0A")
MUTED = colors.HexColor("#5A5A55")
LINE = colors.HexColor("#B9B9B2")
HEAD_BG = colors.HexColor("#F1F0EA")


def register_font():
    global FONT
    for path, name in FONT_CANDIDATES:
        if not os.path.isfile(path):
            continue
        try:
            if path.endswith(".ttc"):
                pdfmetrics.registerFont(TTFont(name, path, subfontIndex=0))
            else:
                pdfmetrics.registerFont(TTFont(name, path))
            FONT = name
            return path
        except Exception:  # noqa: BLE001
            continue
    raise SystemExit("[错误] 找不到可用中文字体，无法渲染 PDF")


def styles():
    base = ParagraphStyle("base", fontName=FONT, fontSize=9.5, leading=15,
                          textColor=INK, alignment=TA_LEFT, wordWrap="CJK")
    return {
        "base": base,
        "title": ParagraphStyle("title", parent=base, fontSize=17, leading=24,
                                alignment=TA_CENTER, spaceAfter=2),
        "sub": ParagraphStyle("sub", parent=base, fontSize=13, leading=20,
                              alignment=TA_CENTER, textColor=MUTED, spaceAfter=10),
        "cell": ParagraphStyle("cell", parent=base, fontSize=9, leading=13.5),
        "section": ParagraphStyle("section", parent=base, fontSize=10.5, leading=16),
        "body": ParagraphStyle("body", parent=base, fontSize=9.5, leading=15.5),
        "label": ParagraphStyle("label", parent=base, fontSize=9.5, leading=14),
    }


def esc(s):
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def para_text(p):
    return "".join(r.text or "" for r in p.runs).strip()


def cell_text(tc):
    out = []
    for p in tc.findall(qn("w:p")):
        t = "".join(n.text or "" for n in p.iter(qn("w:t"))).strip()
        if t:
            out.append(t)
    return out


def parse_rows(tbl):
    """把 w:tbl 解析成行结构：每行 [{col, span, vmerge, texts}]。"""
    rows = []
    for tr in tbl.findall(qn("w:tr")):
        cells, col = [], 0
        for tc in tr.findall(qn("w:tc")):
            span, vmerge = 1, None
            if tc.tcPr is not None:
                gs = tc.tcPr.find(qn("w:gridSpan"))
                if gs is not None:
                    span = int(gs.get(qn("w:val")))
                vm = tc.tcPr.find(qn("w:vMerge"))
                if vm is not None:
                    vmerge = vm.get(qn("w:val")) or "continue"
            cells.append({"col": col, "span": span, "vmerge": vmerge, "texts": cell_text(tc)})
            col += span
        rows.append(cells)
    return rows


def is_long_row(row, ncols):
    """长文本行：内容格几乎占满整行（span >= ncols-1）且文本很长。

    注意：真实模板里长内容行是「标签 1 列 + 内容 4 列」，内容格 span=4，
    不是 5——按 span==ncols 判会全部漏掉（踩过）。
    """
    return any(c["span"] >= ncols - 1 and len("\n".join(c["texts"])) > LONG_CELL
               for c in row)


def make_table(rows, col_w, st):
    data, spans, header_rows = [], [], set()
    for ri, row in enumerate(rows):
        line = [""] * len(col_w)
        for c in row:
            txt = "<br/>".join(esc(t) for t in c["texts"])
            if c["col"] < len(line):
                style = st["section"] if c["span"] >= len(col_w) - 1 else st["cell"]
                line[c["col"]] = RLP(txt, style) if txt else ""
            if c["span"] > 1:
                spans.append(("SPAN", (c["col"], ri),
                              (min(len(col_w) - 1, c["col"] + c["span"] - 1), ri)))
        filled = [x for x in line if x != ""]
        if len(filled) == 1 and line[0] != "":
            header_rows.add(ri)
        data.append(line)

    # 纵向合并：从 restart 行向下数 continue 行
    for ri, row in enumerate(rows):
        for c in row:
            if c["vmerge"] != "restart":
                continue
            n = ri
            for rj in range(ri + 1, len(rows)):
                if not [x for x in rows[rj] if x["col"] == c["col"] and x["vmerge"] == "continue"]:
                    break
                n = rj
            if n > ri:
                spans.append(("SPAN", (c["col"], ri),
                              (min(len(col_w) - 1, c["col"] + c["span"] - 1), n)))

    t = RLTable(data, colWidths=col_w, repeatRows=0, splitByRow=1, splitInRow=0)
    style = [
        ("FONTNAME", (0, 0), (-1, -1), FONT),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (0, 0), (-1, -1), INK),
        ("GRID", (0, 0), (-1, -1), 0.5, LINE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
    ]
    for ri in header_rows:
        style.append(("BACKGROUND", (0, ri), (-1, ri), HEAD_BG))
    style += spans
    t.setStyle(TableStyle(style))
    return t


def label_bar(text, st, width):
    """长文本行的标签条（蓝色左边线 + 浅底整行）。"""
    t = RLTable([[RLP(esc(text), st["label"])]], colWidths=[width])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), FONT),
        ("BACKGROUND", (0, 0), (-1, -1), HEAD_BG),
        ("LINEBEFORE", (0, 0), (0, -1), 2.2, colors.HexColor("#002FA7")),
        ("BOX", (0, 0), (-1, -1), 0.5, LINE),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def render_table(tbl, st, avail):
    grid = tbl.find(qn("w:tblGrid"))
    widths = [int(g.get(qn("w:w"))) for g in grid.findall(qn("w:gridCol"))]
    total = sum(widths) or 1
    col_w = [avail * w / total for w in widths]
    ncols = len(widths)
    rows = parse_rows(tbl)

    story, chunk = [], []

    def flush():
        if chunk:
            story.append(make_table(list(chunk), col_w, st))
            chunk.clear()

    for row in rows:
        if is_long_row(row, ncols):
            flush()
            long_cell = [c for c in row if c["span"] >= ncols - 1][0]
            label_cell = [c for c in row if c["span"] == 1]
            label = "".join(label_cell[0]["texts"]) if label_cell else ""
            story.append(KeepTogether([label_bar(label or "内容", st, avail), Spacer(1, 3)]))
            for t in long_cell["texts"]:
                story.append(RLP(esc(t), st["body"]))
                story.append(Spacer(1, 4))
            story.append(Spacer(1, 8))
        else:
            chunk.append(row)
    flush()
    return story


def convert(src, dst):
    register_font()
    st = styles()
    doc = Document(src)
    body = doc.element.body
    avail = A4[0] - 36 * mm

    story, title_done = [], False
    for ch in body.iterchildren():
        tag = ch.tag.split("}")[-1]
        if tag == "p":
            p = Paragraph(ch, doc)
            txt = para_text(p)
            if not txt:
                continue
            if not title_done and "华为ICT大赛" in txt:
                story.append(RLP(esc(txt), st["title"]))
                title_done = True
            elif title_done and len(story) == 1:
                story.append(RLP(esc(txt), st["sub"]))
            else:
                story.append(RLP(esc(txt), st["base"]))
                story.append(Spacer(1, 3))
        elif tag == "tbl":
            if title_done and len(story) == 1:
                story.append(Spacer(1, 6))
            story.extend(render_table(ch, st, avail))

    if not story:
        raise SystemExit("[错误] 文档里没有可渲染内容")

    def footer(canvas, d):
        canvas.saveState()
        canvas.setFont(FONT, 8)
        canvas.setFillColor(MUTED)
        canvas.drawString(18 * mm, 12 * mm, "装明白 · 作品信息收集表")
        canvas.drawRightString(A4[0] - 18 * mm, 12 * mm, "第 %d 页" % d.page)
        canvas.restoreState()

    pdf = SimpleDocTemplate(dst, pagesize=A4,
                            leftMargin=18 * mm, rightMargin=18 * mm,
                            topMargin=16 * mm, bottomMargin=18 * mm,
                            title="装明白 · 作品信息收集表", author="装明白")
    pdf.build(story, onFirstPage=footer, onLaterPages=footer)
    return dst


def main():
    if len(sys.argv) < 2:
        raise SystemExit("用法：python3 docx_to_pdf.py <input.docx> [output.pdf]")
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else os.path.splitext(src)[0] + ".pdf"
    convert(src, dst)
    print("生成", dst, os.path.getsize(dst), "B")


if __name__ == "__main__":
    main()
