# CodeArts 五环节过程资产（国奖版）

> 记录对象：华为云码道 CodeArts 在本项目中的**真实使用过程**，不是事后补写的说明。
> 原始输出：`raw/stage1_requirement.txt` … `raw/stage5_deploy.txt`（未经编辑）。
> 采集时间：2026-10-29 晚 – 2026-10-30 上午；国奖版复核：2026-11-01。

---

## 0. 环境

| 项 | 值 |
|---|---|
| 码道 CLI 版本 | **26.10.13**（`codearts --version`） |
| 套餐 | 免费体验版（已激活） |
| 可用模型 | DeepSeek-V4.1-Flash / GLM-5.2 / GLM-5.3 / Kimi-K3 / OpenPangu-2.0-Flash / OpenPangu-2.0-Pro |
| 实际使用 | `openpangu-2.0-pro` |
| 凭证方式 | `CODEARTS_CLI_AK` / `CODEARTS_CLI_SK` 环境变量（不入库、不进材料） |
| 工作目录 | 项目根 `zhuangmingbai/`，已加入 `trustedFolders`（否则报「文件夹未被信任」） |

---

## 1. 五环节总览

| 环节 | 状态 | 一句话产出 | 原始记录 |
|---|---|---|---|
| ① 需求理解 | ✅ | 12 条审计规则的「需求—验收」对照表（后扩至 13 条） | `raw/stage1_requirement.txt` |
| ② 代码生成 | ✅ | 本体补 18 个概念，对齐覆盖率 **53.3% → 83.3%** | `raw/stage2_codegen.txt` |
| ③ 项目构建 | ✅ | Dockerfile + .dockerignore（人工修掉 1 个缺陷） | `raw/stage3_build.txt` |
| ④ 问题修复 | ✅ | 空 CSV 上传由 500 改 400，实测通过 | `raw/stage4_fix.txt` |
| ⑤ 部署上线 | ✅ | systemd 单元 + Nginx 反代 + DEPLOY.md 清单 | `raw/stage5_deploy.txt` |

提交记录：`05f749c`（③④⑤）、`d2573a4`（②）、`5ba769c`（基线）。

> **口径提醒**：2026-11-01 新增的 `src/store.py` / `src/cache.py` / `src/llm.py`
> 是**人工开发**，不是码道产出。国奖材料里不要把这一轮算成「码道生成」，
> 否则一问 commit 作者与 diff 就穿帮。诚实的分工是：**码道做外围与本体，人守判定与云原生。**

---

## 2. 环节①：需求理解

**提示词（原文）**：

> 只读分析，不要修改任何文件。读取 data/rules_v0.json 和 src/pipeline.py，输出一张「需求—验收」对照表（Markdown 表格），列：规则ID | 规则名 | 输入 | 输出 | 判据 | 可见证据字段。每个规则一行，判据要写成可验收的条件（例如「集合差非空且金额>0」）。表后追加一行统计：共几条规则。

**产出**：12 行表格，每条给出输入、输出、可验收判据、证据字段。抽样：

| 规则ID | 判据（原文） | 可见证据字段 |
|---|---|---|
| R1_missing_item | 集合差 T \ S 非空（存在模板必做项未在实列中出现） | basis, formula |
| R8_arithmetic | \|合价 − 数量×单价\| > 1 | basis, formula |
| R10_fee_rate | 管理费/总价 > 8% | basis, formula |

**价值**：把「三类审计」从功能描述逼成**可验收条款**。写不出判据的规则，就是没想清楚的规则。

---

## 3. 环节②：代码生成

**提示词（要点）**：读 `out/unmatched_terms.csv` 的 18 个缺口项，补进 `data/ontology_v0.json`；只改数据文件不改代码；保持 schema；补完跑 `eval/eval_alignment.py`；低于 75% 就继续迭代，最多三次。

**结果（可复算）**：

```
概念数        101 → 119   (+18)
同义别名      221 → 286   (+65)
对齐覆盖率    53.3% → 83.3%
本体缺口      30.0% → 0.0%
```

**验证命令与输出**：

```bash
$ python3 eval/eval_alignment.py
- 精确/别名命中（已覆盖）：50 个（83.3%）
- 模糊命中（疑似覆盖，需人工确认）：10 个（16.7%）
- 未命中（本体缺口）：0 个（0.0%）

$ python3 src/pipeline.py
[OK] out/audit_report.md | ... （exit 0，三家样例报告正常生成）
```

**为什么这一步有含金量**：不是「生成了一段代码」，而是**一个可复算的指标被真实改动了**。
评委可以 clone 仓库、删掉这 18 条、重跑评测，看到 53.3%；加回来，看到 83.3%。

---

## 4. 环节③：项目构建

**产出**：`Dockerfile`（31 行）+ `.dockerignore`（61 行）。

生成质量：分层正确（先 COPY requirements.txt 再 COPY .）、清华镜像源、`PYTHONUNBUFFERED=1`、`EXPOSE 8000`。

**人工修掉的缺陷**：原版健康检查写 `curl`，而 `python:3.13-slim` 不含 curl，容器会永远 unhealthy。
已改为标准库探活：

```dockerfile
HEALTHCHECK ... CMD python -c "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8000/health', timeout=5).status==200 else 1)"
```

**国奖版补充**：新增 `docker-compose.yml`（PostgreSQL + Redis + App）用于本地验证 RDS/Redis 逻辑；
仍如实标注「**Docker 构建未在本机验证**」——不把「文件写对了」说成「构建通过了」。

---

## 5. 环节④：问题修复

**缺陷**：上传「只有表头、没有数据行」的 CSV 时，`_audit()` 抛 `ValueError`，被通用 `except` 捕获后返回 **500**。

**修复方式**（不是把 except 写宽，而是分类）：

```python
class EmptyRowsError(ValueError):
    """CSV 解析后没有行项（只有表头或空数据）"""

except EmptyRowsError as e:
    return _err("没有解析到行项", str(e), 400)
except Exception as e:
    return _err("审计失败", "解析或计算过程中出错：%s" % e, 500)
```

**实测验证**：空表头 CSV + 正常单 → 400；正常两单 → 200；`/demo` → 200；`py_compile` 通过。

---

## 6. 环节⑤：部署上线

| 文件 | 内容 |
|---|---|
| `deploy/zhuangmingbai.service` | systemd：`User=deploy`、`EnvironmentFile=-/opt/zhuangmingbai/.env`、`Restart=on-failure` |
| `deploy/nginx.conf` | 80 → 127.0.0.1:8000 反代，`X-Forwarded-For`、`client_max_body_size 8m` |
| `deploy/DEPLOY.md` | 从 clone 到 `/health` 探活，含回滚命令与 .env 配置 |

**真实部署路径**：RDS/OBS 命令行开通；Redis 无创建接口走控制台；ECS 受账户余额限制；
改用 AI 开发者空间 + DevBridge 跑出 HTTPS 公网 Demo（5 路由 200，存证在 `装明白_校赛材料/公网Demo存证/`）。

---

## 6.5 环节⑥：Skill 化（把项目本身变成码道能调用的技能）

前五环节是「用码道改这个项目」。这一环节反过来：**把这个项目做成码道的一个技能**，
让下一次审计只凭一句话就能跑起来。

| 文件 | 作用 |
|---|---|
| `.codeartsdoer/skills/zmb-audit/SKILL.md` | 技能说明书：触发条件、三步流程、参数表、输出怎么读、转述纪律、边界声明 |
| `.codeartsdoer/AGENTS.md` | 五条动手前必须知道的工程约定（判定不经过模型 / 引擎零依赖 / 宁可少报 / 改判定要重算指纹 / 新能力要有测试锁） |
| `scripts/audit_one.py` | 窄入口：`python3 scripts/audit_one.py 报价单.csv --label 甲公司` 一条命令出结果 |

**为什么放在仓库里**：码道的项目级 Skill **随仓库分发**，不在某个人本地。
所以评审 clone 下来就能看到，不需要我们截图自证「我配过」。

**为什么另开窄入口**：完整审计要传五份数据（本体/模板/规则/覆盖率/CSV），
那是给「换行业」用的。对智能体来说五个参数是负担，它只想知道「这个文件有没有问题」。

**说明书的风险是过期**：命令改了、脚本挪了，`SKILL.md` 还写着旧的，
智能体就会照着执行然后「合理地」编一个结果。
所以 `tests/test_skill.py` 给这份 Markdown 写测试——逐个验证引用的脚本真实存在、
真跑一次入口比对输出字段、守门对合同返回 2。

### 采证（R7 的最后一步）

| 项 | 值 |
|---|---|
| 提示词 | `prompts/stage6_skill_prompt.md`（逐字可复制，约 8 分钟） |
| 证据落点 | `raw/stage6_skill.txt`（整段会话，不改一个字） |
| 校验命令 | `python3 scripts/verify_skill_evidence.py` |
| 当前状态 | **🟡 待运行**（有实物、有校验器，缺一次真实会话） |

校验器做的事：把会话里写的**工序行数 / 明细合计 / 可核减漏项 / 可核减重复 / 交付判定 / 判定指纹**
逐项与引擎实跑比对，差 1 分钱即判不一致；同时拦「召回率 100%」这类无口径断言。
对不上就明说不能引用——这样这份证据证明的不只是「跑过」，是**跑出来的数是真的**。

---

## 7. 真实观察（建议写进答辩，别藏）

1. **免费套餐排队严重**：单次会话出现 26 次「模型排队，您排在第 2 位」，单环节耗时 10–25 分钟。
   所以「AI 开发提效」的真实含义是：**省的是写代码的时间，不是等结果的时间**。
2. **模型会自动生成临时脚本**：第②环节生成了 `calc_coverage.py`、`coverage_calc_v2~v4.py` 等 8 个临时文件，
   已人工清理。这反而证明架构主张：**AI 负责生成，人负责边界**。

---

## 8. 复现步骤（评委可照做）

```bash
# 1. 装 CLI
sh -c "$(curl -L https://cnnorth4-cloudide-marketplace.obs.cn-north-4.myhuaweicloud.com/codearts/cli_tui/install_script/install.sh)"
export PATH=~/.codeartsdoer/installers:$PATH

# 2. 配凭证（用你自己的 AK/SK）
export CODEARTS_CLI_AK=<AK> CODEARTS_CLI_SK=<SK>

# 3. 复现第②环节的评测
cd zhuangmingbai
python3 eval/eval_alignment.py      # 应输出 83.3%

# 4. 回退验证（可选，证明指标是真被这 18 条驱动的）
git revert --no-edit d2573a4
python3 eval/eval_alignment.py      # 应回到 53.3%
git revert --no-edit HEAD
```

---

## 9. 提交用截图清单（账号持有人补）

| # | 截图 | 要求 |
|---|---|---|
| 1 | 码道 CLI 登录成功页 / `codearts --version` | 能看到版本号 26.10.13 |
| 2 | 五环节会话各一张（stage1–5） | 与 `raw/` 文本对应；可只截头部与关键输出 |
| 2.5 | **Skill 调用会话**（stage6） | 能看到 `SKILL.md` 被读取 + `audit_one.py` 的执行结果；同时存 `raw/stage6_skill.txt` |
| 3 | `git log` 中码道提交 | 能看到 `d2573a4` / `05f749c` |
| 4 | RDS 控制台实例页 | 打码账号 ID，保留实例名/版本/状态 |
| 5 | Redis 控制台实例页 | 若已开通；未开通则截「创建页」并注明待开通 |
| 6 | OBS 桶列表 | 保留桶名/区域 |
| 7 | 公网 Demo 地址栏 + `/health` | 域名完整；与视频一致 |
| 8 | 开源仓库首页 + LICENSE | Gitee 公开可访问 |
