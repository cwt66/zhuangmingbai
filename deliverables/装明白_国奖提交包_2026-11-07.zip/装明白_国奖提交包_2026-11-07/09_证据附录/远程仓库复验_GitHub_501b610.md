# GitHub 复验记录（2026-11-07 · `501b610`）

> 目的：证明 GitHub 上的仓库是**公开、可匿名克隆、且 CI 真的跑过**的，不是只推了个壳。
> 仓库：https://github.com/cwt66/zhuangmingbai ｜ 许可 MIT ｜ 默认分支 `main`
> 与 Gitee 的关系：同一 commit（`501b610`），两端各匿名克隆验证一次。

---

## 1. 仓库状态

| 项 | 值 |
|---|---|
| 可见性 | **public** |
| 默认分支 | `main` |
| 当前 commit | `501b610`（与 Gitee 一致） |
| 标签 | `v0.5.0` → `2391a0a`（v0.5.0 发布快照） |
| LICENSE | MIT |
| 描述 | 装明白 · 可计算审计：装修报价漏项/重复/对账，可复算 |

## 2. CI（GitHub Actions）

| 项 | 值 |
|---|---|
| 工作流 | `.github/workflows/ci.yml`（`ci`） |
| 运行 | run **42331161041**，`501b610`，**success**（2026-11-07 02:50 UTC） |
| 地址 | https://github.com/cwt66/zhuangmingbai/actions/runs/42331161041 |
| 内容 | checkout → Python 3.12 → `pip install -r requirements.txt` → 装中文字体 → `bash scripts/check_all.sh` |

> 第一次运行（`8e49f8d`）是**失败**的：`RuntimeError: reportlab 未安装`。
> 那是真缺陷——服务端 PDF 已是交付方式，requirements 却没列它。
> 修法：补 `reportlab`、`report_pdf.has_cjk_font()` 探测字体、CI 装 `fonts-wqy-zenhei`；
> 第二次（`8bd66e4`）转绿；之后 `501b610` 只改了文档，第三次运行同样绿。
> 失败那次保留在 Actions 历史里，不删。

## 3. 匿名 clone + 实跑（从 GitHub，非本地）

```bash
$ git clone --depth 1 https://github.com/cwt66/zhuangmingbai.git
$ cd zhuangmingbai && git log --oneline -1
501b610 fix(ci): requirements 补 reportlab + CI 装中文字体，PDF 链路才能在 Linux 上跑

$ bash scripts/check_all.sh
Ran 145 tests in 5.5s
OK
== 8/9 冻结指纹 + 隐私扫描
sh_zhuoguan     行127 对齐111 | 指纹 2ab9413a0d32ebab  = 与冻结基线一致
huaxibeian      行120 对齐105 | 指纹 456e1bd94ab39a08  = 与冻结基线一致
szxinxin_clinic 行168 对齐113 | 指纹 3d33c49caf60f48d  = 与冻结基线一致
[OK] 未发现手机号 / 身份证 / 邮箱 / 银行卡 / 明确上下文姓名。
[ALL GREEN] 全部检查通过。
```

原始输出：`运行存证/check_all_501b610_github.txt`（未编辑，含 GitHub 克隆命令与时间）

## 4. Gitee 与 GitHub 的差异：只有托管方

| 项 | Gitee | GitHub |
|---|---|---|
| commit | `501b610` | `501b610` |
| 分支 / 标签 | `main` / `v0.5.0` | `main` / `v0.5.0` |
| 匿名 clone | 145 tests `[ALL GREEN]` | 145 tests `[ALL GREEN]` |
| CI | 无（Gitee Go 未启用） | GitHub Actions 绿 |

代码、数据、评测脚本逐字节一致；两端的 `git rev-parse HEAD` 相同。

## 5. 评委复验命令

```bash
# 国内
git clone https://gitee.com/Cwt66/zhuangmingbai.git
# 海外 / 有 GitHub 账号
git clone https://github.com/cwt66/zhuangmingbai.git
cd zhuangmingbai && bash scripts/check_all.sh
```

> 若在受限网络里 GitHub 域名被解析成 `198.18.x.x`（代理 fake-IP），
> 可直接用真实 IP：`git -c http.curloptResolve=github.com:443:<真实IP> clone ...`，
> 真实 IP 用 `https://1.1.1.1/dns-query?name=github.com&type=A` 查。
> 这一段是本机推送时踩到的，写在这里省得下一个人再踩。
