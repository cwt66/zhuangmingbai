# 评测原始输出（可复算）

> 这些文件由仓库脚本生成，未手工修改。评委可重跑核对。
> 生成时点：**2026-11-05 19:35 CST｜commit `c56b706`｜243 测试**（`bash scripts/check_all.sh` 一次跑完）。
> **历史存证，不回填**：以下是 `c56b706` 时点的原始输出，243 测试是当时的真实值。
> 当前口径 278 测试 / 16 步见 `评测数字总表.md`；本目录文件保持原样，便于逐字段复算。


| 文件 | 生成命令 | 说明 |
|---|---|---|
| `golden_eval.md` / `.json` | `python3 eval/golden_eval.py` | 黄金标注 auto/all 两档 + Wilson CI + 错误明细 |
| `ablation.md` / `.json` | `python3 eval/ablation.py` | L0→L3 消融 |
| `alignment_report.md` | `python3 eval/eval_alignment.py` | 60 个项目名对齐覆盖率 |
| `audit_result.json` | `python3 src/pipeline.py` | 三单合成样例的判定结果（指纹基线） |
| `注入实验_最新.md` | `python3 eval/injection_test.py` | 242 例注入（下限校验，不是召回率） |
| `gate.md` | `python3 eval/gate.py` | 评测门禁：6 项 PASS/FAIL |

## 重新生成

```bash
cd zhuangmingbai
bash scripts/check_all.sh
# 或逐个：
python3 eval/golden_eval.py
python3 eval/ablation.py
python3 eval/eval_alignment.py
python3 src/pipeline.py
python3 eval/injection_test.py
python3 eval/gate.py
```

## 注意

- `golden_eval` 的 auto 档是**进核减金额**的结论；all 档含 review（待确认）结论，两档不能混着说。
- `injection_test` 是**下限校验**，不是召回率；对外表述必须带这句。
- `audit_result.json` 与 `eval/predictions/` 是冻结基线；改任何规则/本体都会导致指纹漂移，必须解释原因。
