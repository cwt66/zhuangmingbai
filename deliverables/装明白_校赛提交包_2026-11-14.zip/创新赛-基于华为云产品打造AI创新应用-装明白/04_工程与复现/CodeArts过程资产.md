# CodeArts 五环节过程资产

> 记录对象：华为云码道 CodeArts 在本项目中的真实使用过程，原始会话逐字保留。
> 原始输出：`raw/stage1_requirement.txt` … `raw/stage6_skill.txt`（未经编辑）。
> 复核：`python3 scripts/verify_skill_evidence.py` ｜ `bash scripts/check_all.sh`

---

## 0. 环境

| 项 | 值 |
|---|---|
| 码道 CLI 版本 | **26.10.13**（`codearts --version`） |
| 可用模型 | DeepSeek-V4.1-Flash / GLM-5.2 / GLM-5.3 / Kimi-K3 / OpenPangu-2.0-Flash / OpenPangu-2.0-Pro |
| 实际使用 | `openpangu-2.0-pro` |
| 凭证方式 | `CODEARTS_CLI_AK` / `CODEARTS_CLI_SK` 环境变量（不入库、不进材料） |
| 工作目录 | 项目根 `zhuangmingbai/`，已加入 `trustedFolders` |

---

## 1. 五环节总览

| 环节 | 产出 | 可复核证据 |
|---|---|---|
| ① 需求理解 | 12 条审计规则的「需求—验收」对照表（后扩至 13 条） | `raw/stage1_requirement.txt` |
| ② 代码生成 | 本体补 18 个概念，对齐覆盖率 **53.3% → 83.3%** | `raw/stage2_codegen.txt`、commit `d2573a4` |
| ③ 项目构建 | Dockerfile、.dockerignore、docker-compose | `raw/stage3_build.txt`、commit `05f749c` |
| ④ 问题修复 | 空 CSV 上传由 500 改 400，回归用例锁住 | `raw/stage4_fix.txt` |
| ⑤ 部署上线 | systemd + Nginx + DEPLOY.md，ECS 实跑 | `raw/stage5_deploy.txt`、服务器复验证据 |
| ⑥ Skill 化 | 项目级技能 `zmb-audit`，一句话触发审计 | `raw/stage6_skill.txt`、`verify_skill_evidence.py` |

提交记录：`5ba769c`（基线）、`d2573a4`（②）、`05f749c`（③④⑤）。

> 分工说明：**码道负责外围与本体（需求判据、概念补齐、构建与部署脚手架、技能化），
> 人负责判定内核与云原生接入（规则、证据分级、账本、存储/缓存/模型适配）。**
> 这条分工在 commit 作者与 diff 里都能对上，也是下面每个环节的读法。

---

## 2. 环节①：需求理解

**提示词（原文）**：

> 只读分析，不要修改任何文件。读取 data/rules_v0.json 和 src/pipeline.py，输出一张「需求—验收」对照表（Markdown 表格），列：规则ID | 规则名 | 输入 | 输出 | 判据 | 可见证据字段。每个规则一行，判据要写成可验收的条件（例如「集合差非空且金额>0」）。表后追加一行统计：共几条规则。

**产出**：12 行表格，每条给出输入、输出、可验收判据、证据字段。抽样：

| 规则ID | 判据（原文） | 可见证据字段 |
|---|---|---|
| R1_missing_item | 集合差 T \ S 非空（存在模板必做项未在实列中出现） | basis, formula |
| R8_arithmetic | \|合价 − 数量×单价\| > 1 | basis, formula |
| R10_fee_rate | 管理费/总价 > 8% | basis, formula |

**价值**：把「三类审计」从功能描述逼成可验收条款。写不出判据的规则，就是没想清楚的规则。
这张表后来直接变成 13 条规则的验收清单，也成了 `tests/` 里规则测试的命名依据。

---

## 3. 环节②：代码生成

**提示词（要点）**：读 `out/unmatched_terms.csv` 的 18 个缺口项，补进 `data/ontology_v0.json`；只改数据文件不改代码；保持 schema；补完跑 `eval/eval_alignment.py`；低于 75% 就继续迭代，最多三次。

**结果（可复算）**：

```
概念数        101 → 119   (+18)
同义别名      221 → 286   (+65)
对齐覆盖率    53.3% → 83.3%
本体缺口      30.0% → 0.0%
```

**验证命令与输出**：

```bash
$ python3 eval/eval_alignment.py
- 精确/别名命中（已覆盖）：50 个（83.3%）
- 模糊命中（疑似覆盖，需人工确认）：10 个（16.7%）
- 未命中（本体缺口）：0 个（0.0%）

$ python3 src/pipeline.py
[OK] out/audit_report.md | ... （exit 0，三家样例报告正常生成）
```

**为什么这一步有含金量**：不是「生成了一段代码」，而是**一个可复算的指标被真实改动了**。
评委可以 clone 仓库、`git revert d2573a4` 后重跑评测看到 53.3%，再恢复看到 83.3%。

---

## 4. 环节③：项目构建

**产出**：`Dockerfile`（31 行）+ `.dockerignore`（61 行）+ `docker-compose.yml`。

生成质量：分层正确（先 COPY requirements.txt 再 COPY .）、镜像源可用、`PYTHONUNBUFFERED=1`、`EXPOSE 8000`。

**人工复核的一处关键改动**：原版健康检查调用 `curl`，而 `python:3.13-slim` 不含该二进制，
容器会一直 unhealthy。改为标准库探活，镜像不需要额外装包：

```dockerfile
HEALTHCHECK ... CMD python -c "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8000/health', timeout=5).status==200 else 1)"
```

**为什么这属于「项目构建」而不是「写文件」**：健康检查是编排系统判断服务是否可用的唯一信号，
它写错，容器永远起不来。这里体现的是「AI 生成 + 人复核边界」的协作方式：
生成负责覆盖率，复核负责运行语义。

`docker-compose.yml` 把 PostgreSQL + Redis + 应用编排在一起，本地与云端用同一套服务名与端口，
切换环境只改 `.env`。

---

## 5. 环节④：问题修复

**问题**：上传「只有表头、没有数据行」的 CSV 时，`_audit()` 抛 `ValueError`，被通用 `except` 捕获后返回 **500**。

**修复方式**（不是把 except 写宽，而是分类）：

```python
class EmptyRowsError(ValueError):
    """CSV 解析后没有行项（只有表头或空数据）"""

except EmptyRowsError as e:
    return _err("没有解析到行项", str(e), 400)
except Exception as e:
    return _err("审计失败", "解析或计算过程中出错：%s" % e, 500)
```

**实测验证**：空表头 CSV + 正常单 → 400；正常两单 → 200；`/demo` → 200；`py_compile` 通过；
回归用例写进 `tests/test_api.py`，此后每次自检都会跑。

**方法论**：错误码是接口契约的一部分。用户输入问题返回 4xx 并说明原因，系统问题返回 5xx，
两者不能混在一个 `except` 里——这条约定后来被写进 `.codeartsdoer/AGENTS.md`。

---

## 6. 环节⑤：部署上线

| 文件 | 内容 |
|---|---|
| `deploy/zhuangmingbai.service` | systemd：`User=deploy`、`EnvironmentFile=-/opt/zhuangmingbai/.env`、`Restart=on-failure` |
| `deploy/nginx.conf` | 80/443 → `127.0.0.1:8000` 反代，`X-Forwarded-For`、`client_max_body_size 8m` |
| `deploy/DEPLOY.md` | 从 clone 到 `/health` 探活，含回滚命令与 .env 配置 |

**上线结果**：ECS `s6.medium.2`（贵阳一）+ Nginx + systemd 实跑，公网 **7 个路由 200**，
服务器侧 `bash scripts/check_all.sh` 20 步 `[ALL GREEN]`、`344 tests`；
DCS for Redis 接管缓存（停掉本地 Redis 后仍命中），MaaS openPangu 负责报告解读。
演示完成后按需释放实例，按 SOP 40 分钟重建，判定指纹一致。

---

## 7. 环节⑥：Skill 化（把项目本身变成码道能调用的技能）

前五环节是「用码道改这个项目」。这一环节反过来：**把这个项目做成码道的一个技能**，
让下一次审计只凭一句话就能跑起来。

| 文件 | 作用 |
|---|---|
| `.codeartsdoer/skills/zmb-audit/SKILL.md` | 技能说明书：触发条件、三步流程、参数表、输出怎么读、边界声明 |
| `.codeartsdoer/AGENTS.md` | 五条工程约定（判定不经过模型 / 引擎零依赖 / 宁可少报 / 改判定要重算指纹 / 新能力要有测试锁） |
| `scripts/audit_one.py` | 窄入口：`python3 scripts/audit_one.py 报价单.csv --label 甲公司` 一条命令出结果 |

**为什么放在仓库里**：码道的项目级 Skill 随仓库分发，不在某个人本地。
评审 clone 下来就能看到，不需要截图自证「我配过」。

**为什么另开窄入口**：完整审计要传五份数据（本体/模板/规则/覆盖率/CSV），
那是给「换行业」用的。对智能体来说五个参数是负担，它只想知道「这个文件有没有问题」。

**说明书由测试守住**：`tests/test_skill.py` 逐个验证 `SKILL.md` 引用的脚本真实存在、
真跑一次入口比对输出字段、守门对合同返回 2——文档与代码不允许脱节。

### 采证

| 项 | 值 |
|---|---|
| 提示词 | `prompts/stage6_skill_prompt.md`（逐字可复制，约 8 分钟） |
| 证据落点 | `raw/stage6_skill.txt`（整段会话，不改一个字） |
| 校验命令 | `python3 scripts/verify_skill_evidence.py` |
| 状态 | **已采集并校验通过**（2026-11-13 16:30） |

**采集结果**（`codearts run --full_access`，HEAD `0f39a8a`，输出未改写）：

| 字段 | 证据里写的 | 服务器实跑 | 判定 |
|---|---:|---:|---|
| 工序行数 | 123 | 123 | ✅ |
| 明细合计 | 153,384.00 | 153,384.00 | ✅ |
| 可核减漏项 | 618.40 | 618.40 | ✅ |
| 可核减重复 | 182.00 | 182.00 | ✅ |
| 交付判定 | pass | pass | ✅ |
| 判定指纹 | `52bf7b635204fd96` | `52bf7b635204fd96` | ✅ |

> 说明：会话由码道 CLI 执行，鉴权用华为云 AK/SK；被沙箱拦截时智能体明确回答
> 「没有原始输出、不编造数字」，放开权限后才实跑。

校验器做的事：把会话里写的**工序行数 / 明细合计 / 可核减漏项 / 可核减重复 / 交付判定 / 判定指纹**
逐项与引擎实跑比对，差 1 分钱即判不一致；同时拦「召回率 100%」这类无口径断言。
对不上就明说不能引用——这样这份证据证明的不只是「跑过」，是**跑出来的数是真的**。

---

## 8. 复现步骤（评委可照做）

```bash
# 1. 装 CLI
sh -c "$(curl -L https://cnnorth4-cloudide-marketplace.obs.cn-north-4.myhuaweicloud.com/codearts/cli_tui/install_script/install.sh)"
export PATH=~/.codeartsdoer/installers:$PATH

# 2. 配凭证（用你自己的 AK/SK）
export CODEARTS_CLI_AK=<AK> CODEARTS_CLI_SK=<SK>

# 3. 复现第②环节的评测
cd zhuangmingbai
python3 eval/eval_alignment.py      # 应输出 83.3%

# 4. 回退验证（证明指标真由这 18 条驱动）
git revert --no-edit d2573a4
python3 eval/eval_alignment.py      # 应回到 53.3%
git revert --no-edit HEAD
```

---

## 9. 材料索引

| 材料 | 位置 |
|---|---|
| 五环节原始会话 | `raw/stage1_requirement.txt` … `stage5_deploy.txt` |
| Skill 实跑会话 | `raw/stage6_skill.txt` |
| 技能说明书 | `.codeartsdoer/skills/zmb-audit/SKILL.md` |
| 码道提交 | `git log --oneline`：`d2573a4`、`05f749c` |
| 服务器复验 | `data/server_attestation_v0.json` + 脱敏日志 |
| 公网 Demo 截图 | `装明白_校赛材料/公网Demo存证/` |
