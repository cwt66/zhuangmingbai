# 源码与复现入口

> 本目录是「工程与复现」材料。源码不在本目录重复打包，按下面任一入口获取即可。

## 入口一：离线演示包（随包提交，推荐）

`02_演示材料/装明白_离线演示包.zip` 就是**完整源码包**（235 个文件，含 `src/`、`tests/`、`data/`、`docs/`、`eval/`、`scripts/`）。

```bash
unzip 装明白_离线演示包.zip
cd zhuangmingbai
bash run_offline.sh                # 三单 → out/audit_report.html
bash scripts/check_all.sh          # 20 步自检，期望 [ALL GREEN]
python3 -m unittest discover -s tests   # 单元测试
```

## 入口二：公开仓库

- Gitee：https://gitee.com/Cwt66/zhuangmingbai （MIT）
- 分支：`main`
- 版本：`v0.5.0`
- 生成本材料时的 commit：`5a76832`

```bash
git clone https://gitee.com/Cwt66/zhuangmingbai.git
cd zhuangmingbai
bash scripts/check_all.sh
```

## 入口三：云上复现

`部署与复现SOP.md` 给出 ECS + Nginx + systemd + DCS Redis + MaaS 的完整步骤；
按 SOP 约 40 分钟可从零重建公网 Demo，重建后的判定指纹与材料记录一致。

## 读代码建议顺序

| 顺序 | 文件 | 看什么 |
|---|---|---|
| 1 | `src/pipeline.py` | 五层流水线如何串起来 |
| 2 | `src/ontology.py` | 119 概念 / 388 别名的四级匹配 |
| 3 | `src/rules.py` + `data/rules_v0.json` | 13 条规则如何求值、证据字段怎么填 |
| 4 | `src/evidence.py` | 四信号加权与三档处置 |
| 5 | `src/ledger.py` + `eval/ledger_chain.py` | 哈希链账本与攻击套件 |
| 6 | `tests/` | 344 个测试，按模块对应到上面五层 |

## 一句话

**源码、数据、测试、评测脚本都在离线包里；仓库地址用于看提交历史与 CI。**
两边是同一份代码，commit 以本页记录为准。
